<?php
/**
 * Default page template — fallback for pages without a custom template
 * Loads home page template as fallback
 */
if (!defined('ABSPATH')) exit;

get_template_part('page-home');
