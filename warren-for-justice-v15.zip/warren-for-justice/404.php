<?php
/**
 * 404 page — redirect to home
 */
if (!defined('ABSPATH')) exit;

wp_redirect(home_url('/'), 301);
exit;
