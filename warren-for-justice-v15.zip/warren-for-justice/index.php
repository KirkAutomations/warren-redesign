<?php
/**
 * Default template — redirects to home page
 */
if (!defined('ABSPATH')) exit;

// For any page/post that doesn't have a custom template, redirect to home
wp_redirect(home_url('/'));
exit;
