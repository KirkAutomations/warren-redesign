<?php
/**
 * Warren for Justice - Theme Functions
 * 
 * Aggressively strips all plugin/theme CSS and JS to prevent conflicts
 * with our fully-inline page templates.
 */

if (!defined('ABSPATH')) exit;

// Theme setup
add_action('after_setup_theme', function() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption']);
});

// Remove ALL emoji scripts
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('admin_print_scripts', 'print_emoji_detection_script');
remove_action('admin_print_styles', 'print_emoji_styles');

// Remove unnecessary head items
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'rest_output_link_wp_head');
remove_action('wp_head', 'wp_oembed_add_discovery_links');
remove_action('wp_head', 'wp_oembed_add_host_js');
remove_action('wp_head', 'feed_links', 2);
remove_action('wp_head', 'feed_links_extra', 3);

// Disable WP admin bar on frontend (prevents extra CSS/JS injection)
add_filter('show_admin_bar', '__return_false');

// Nuclear option: dequeue ALL frontend styles and scripts from plugins
add_action('wp_enqueue_scripts', function() {
    global $wp_styles, $wp_scripts;
    
    // Dequeue ALL styles
    foreach ($wp_styles->queue as $handle) {
        wp_dequeue_style($handle);
    }
    
    // Dequeue ALL scripts  
    foreach ($wp_scripts->queue as $handle) {
        wp_dequeue_script($handle);
    }
}, 9999);

// Also prevent Elementor from loading
add_action('elementor/frontend/after_enqueue_styles', function() {
    global $wp_styles;
    foreach ($wp_styles->queue as $handle) {
        if (strpos($handle, 'elementor') !== false) {
            wp_dequeue_style($handle);
        }
    }
}, 9999);

add_action('elementor/frontend/after_enqueue_scripts', function() {
    global $wp_scripts;
    foreach ($wp_scripts->queue as $handle) {
        if (strpos($handle, 'elementor') !== false) {
            wp_dequeue_script($handle);
        }
    }
}, 9999);

// Prevent Jetpack from adding CSS
add_filter('jetpack_implode_frontend_css', '__return_false');
add_filter('jetpack_sharing_counts', '__return_false');

// Prevent Yoast from adding scripts to frontend
add_action('wp_head', function() {
    // Remove Yoast structured data (we have our own JSON-LD)
    if (class_exists('WPSEO_Frontend')) {
        remove_action('wpseo_head', [WPSEO_Frontend::get_instance(), 'head'], 1);
    }
}, 1);

// Remove WP block library CSS
add_action('wp_enqueue_scripts', function() {
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('wp-block-library-theme');
    wp_dequeue_style('wc-blocks-style');
    wp_dequeue_style('global-styles');
}, 100);

// Remove type attributes for cleaner HTML
add_filter('style_loader_tag', function($tag) { return ''; }, 9999, 4);
add_filter('script_loader_tag', function($tag) { return ''; }, 9999, 3);

// Helper function for nav URLs
function warren_nav_url($page_slug) {
    if ($page_slug === 'home' || $page_slug === 'index') {
        return home_url('/');
    }
    return home_url('/' . $page_slug . '/');
}

// Auto-create pages on theme activation
add_action('after_switch_theme', function() {
    $pages = [
        'media-appearances' => ['title' => 'Media', 'template' => 'page-media.php'],
    ];
    
    foreach ($pages as $slug => $info) {
        $existing = get_page_by_path($slug);
        if (!$existing) {
            $page_id = wp_insert_post([
                'post_title' => $info['title'],
                'post_name' => $slug,
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_content' => '',
            ]);
            
            if ($page_id && $info['template']) {
                update_post_meta($page_id, '_wp_page_template', $info['template']);
            }
        }
    }
});
