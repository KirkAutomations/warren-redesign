<?php
/*
Template Name: Media Page
*/
?>
<!DOCTYPE html>
<html lang="en" data-theme="patriot">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Media &amp; Opinions | Warren for Michigan Supreme Court</title>
<meta name="description" content="Judge Michael Warren's media appearances, Patriot Lessons podcast & TV show, books, documents, and featured press coverage. Candidate for Michigan Supreme Court &mdash; Defender of the Constitution.">
<meta name="keywords" content="Judge Michael Warren, media, Patriot Lessons, podcast, TV show, America's Survival Guide, press coverage, Michigan Supreme Court, Warren for Supreme Court">
<meta property="og:title" content="Media &amp; Opinions | Warren for Michigan Supreme Court">
<meta property="og:description" content="Media appearances, Patriot Lessons podcast, publications, and press coverage featuring Judge Michael Warren &mdash; Candidate for Michigan Supreme Court.">
<meta property="og:image" content="https://judgemichaelwarren.com/wp-content/uploads/2022/01/Michael_D._Warren_Jr._Fixed.png">
<meta property="og:url" content="https://judgemichaelwarren.com/media">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary_large_image">
<link rel="canonical" href="https://judgemichaelwarren.com/media">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "CollectionPage",
  "name": "Media & Opinions - Judge Michael Warren",
  "description": "Media appearances, publications, podcast, and press coverage featuring Judge Michael Warren.",
  "url": "https://judgemichaelwarren.com/media",
  "mainEntity": {
    "@type": "Person",
    "name": "Judge Michael Warren",
    "jobTitle": "Candidate for Michigan Supreme Court"
  }
}
</script>
<style>
/* === RESET & BASE === */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;font-size:16px}
body{font-family:'Inter',-apple-system,BlinkMacSystemFont,sans-serif;line-height:1.7;overflow-x:hidden;-webkit-font-smoothing:antialiased}
a{text-decoration:none;color:inherit;transition:color .3s}
img{max-width:100%;height:auto;display:block}
ul,ol{list-style:none}
h1,h2,h3,h4,h5,h6{font-family:'Playfair Display',Georgia,serif;line-height:1.2;font-weight:700}
.skip-link{position:absolute;top:-100%;left:50%;transform:translateX(-50%);background:var(--accent);color:#fff;padding:12px 24px;z-index:100000;border-radius:0 0 8px 8px;font-weight:600}
.skip-link:focus{top:0}

/* === THEMES === */
[data-theme="patriot"]{--primary:#1a2744;--primary-dark:#0f1a30;--primary-light:#2a3d60;--accent:#c9a84c;--accent-light:#dbc070;--accent-dark:#a88a35;--bg:#ffffff;--bg-alt:#f5f5f7;--bg-dark:#0f1a30;--text:#1a1a2e;--text-light:#555;--text-on-dark:#ffffff;--text-muted:#888;--card-bg:#ffffff;--card-shadow:rgba(26,39,68,0.08);--nav-bg:rgba(26,39,68,0.95);--nav-scrolled:rgba(15,26,48,0.97);--border:rgba(26,39,68,0.1);--gradient-hero:linear-gradient(135deg,#0f1a30 0%,#1a2744 50%,#2a3d60 100%);--gradient-accent:linear-gradient(135deg,#c9a84c,#dbc070);--shimmer-color:#c9a84c;--particle-color:201,168,76}
[data-theme="constitution"]{--primary:#1c1c2e;--primary-dark:#111120;--primary-light:#2d2d4a;--accent:#8b2332;--accent-light:#a83545;--accent-dark:#6e1a27;--bg:#f4f0e8;--bg-alt:#ebe5d8;--bg-dark:#111120;--text:#1c1c2e;--text-light:#555;--text-on-dark:#e8e0d0;--text-muted:#888;--card-bg:#faf6ee;--card-shadow:rgba(28,28,46,0.08);--nav-bg:rgba(28,28,46,0.95);--nav-scrolled:rgba(17,17,32,0.97);--border:rgba(28,28,46,0.1);--gradient-hero:linear-gradient(135deg,#111120 0%,#1c1c2e 50%,#2d2d4a 100%);--gradient-accent:linear-gradient(135deg,#8b2332,#a83545);--shimmer-color:#d4c5a0;--particle-color:212,197,160}
[data-theme="liberty"]{--primary:#1a2744;--primary-dark:#0f1a30;--primary-light:#2a3d60;--accent:#c9a84c;--accent-light:#dbc070;--accent-dark:#a88a35;--bg:#faf8f3;--bg-alt:#f0ede4;--bg-dark:#1a2744;--text:#1a2744;--text-light:#4a5568;--text-on-dark:#faf8f3;--text-muted:#718096;--card-bg:#ffffff;--card-shadow:rgba(26,39,68,0.06);--nav-bg:rgba(250,248,243,0.95);--nav-scrolled:rgba(250,248,243,0.98);--border:rgba(26,39,68,0.08);--gradient-hero:linear-gradient(135deg,#1a2744 0%,#2a3d60 50%,#3a5080 100%);--gradient-accent:linear-gradient(135deg,#c9a84c,#dbc070);--shimmer-color:#c9a84c;--particle-color:201,168,76}

/* === LOADING SCREEN === */
.loader-screen{position:fixed;top:0;left:0;width:100%;height:100%;background:var(--bg-dark);display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:999999;transition:opacity .6s ease,visibility .6s ease}
.loader-screen.hidden{opacity:0;visibility:hidden;pointer-events:none}
.loader-logo{width:280px;opacity:0;animation:loaderFade 1.5s ease forwards}
@keyframes loaderFade{0%{opacity:0;transform:scale(.9)}50%{opacity:1;transform:scale(1.02)}100%{opacity:1;transform:scale(1)}}
.loader-bar{position:absolute;bottom:40%;left:50%;transform:translateX(-50%);width:200px;height:2px;background:rgba(255,255,255,.1);border-radius:2px;overflow:hidden}
.loader-bar::after{content:'';position:absolute;left:0;top:0;height:100%;width:0;background:var(--gradient-accent);animation:loaderProgress 1.5s ease forwards}
@keyframes loaderProgress{to{width:100%}}

/* === SCROLL PROGRESS === */
.scroll-progress{position:fixed;top:0;left:0;height:3px;background:var(--gradient-accent);width:0%;z-index:100001;transition:width .1s linear}

/* === NAVIGATION === */
.nav{position:fixed;top:0;left:0;right:0;z-index:10000;padding:18px 0;background:transparent;transition:all .4s cubic-bezier(.4,0,.2,1)}
.nav.scrolled{padding:10px 0;background:var(--nav-scrolled);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);box-shadow:0 2px 30px rgba(0,0,0,.15)}
[data-theme="liberty"] .nav{background:transparent}
[data-theme="liberty"] .nav.scrolled{background:var(--nav-scrolled);box-shadow:0 1px 20px rgba(0,0,0,.06)}
.nav-inner{max-width:1400px;margin:0 auto;padding:0 40px;display:flex;align-items:center;justify-content:space-between}
.nav-logo img{height:72px;transition:height .3s;filter:drop-shadow(0 2px 8px rgba(0,0,0,.25));background:rgba(255,255,255,1);padding:10px 16px;border-radius:10px;border:1px solid rgba(0,0,0,.08)}
.nav.scrolled .nav-logo img{height:56px}
.nav-links{display:flex;gap:32px;align-items:center}
.nav-links a{font-size:.88rem;font-weight:500;letter-spacing:.3px;color:var(--text-on-dark);position:relative;padding:4px 0;transition:color .3s}
[data-theme="liberty"] .nav-links a{color:var(--text)}
.nav-links a::after{content:'';position:absolute;bottom:-2px;left:0;width:0;height:2px;background:var(--accent);transition:width .3s ease}
.nav-links a:hover::after,.nav-links a.active::after{width:100%}
.nav-links a:hover{color:var(--accent-light)}
.theme-switcher{display:flex;background:rgba(255,255,255,.1);border-radius:30px;padding:3px;border:1px solid rgba(255,255,255,.15);backdrop-filter:blur(10px)}
[data-theme="liberty"] .theme-switcher{background:rgba(0,0,0,.05);border-color:rgba(0,0,0,.1)}
.theme-btn{padding:5px 14px;border-radius:25px;border:none;cursor:pointer;font-size:.72rem;font-weight:600;font-family:'Inter',sans-serif;background:transparent;color:rgba(255,255,255,.6);transition:all .3s;letter-spacing:.5px}
[data-theme="liberty"] .theme-btn{color:rgba(0,0,0,.4)}
.theme-btn.active{background:var(--accent);color:#fff;box-shadow:0 2px 10px rgba(0,0,0,.2)}
.theme-btn:hover:not(.active){color:#fff;background:rgba(255,255,255,.15)}
[data-theme="liberty"] .theme-btn:hover:not(.active){color:var(--text);background:rgba(0,0,0,.08)}
.hamburger{display:none;flex-direction:column;gap:5px;cursor:pointer;padding:8px;z-index:10001;background:none;border:none}
.hamburger span{display:block;width:24px;height:2px;background:var(--text-on-dark);transition:all .3s;border-radius:2px}
[data-theme="liberty"] .hamburger span{background:var(--text)}
.hamburger.active span:nth-child(1){transform:rotate(45deg) translate(5px,5px)}
.hamburger.active span:nth-child(2){opacity:0}
.hamburger.active span:nth-child(3){transform:rotate(-45deg) translate(5px,-5px)}
.mobile-menu{position:fixed;top:0;right:-100%;width:320px;height:100vh;background:var(--bg-dark);z-index:10000;padding:100px 40px 40px;transition:right .4s cubic-bezier(.4,0,.2,1);box-shadow:-10px 0 40px rgba(0,0,0,.3)}
.mobile-menu.open{right:0}
.mobile-menu a{display:block;padding:16px 0;font-size:1.1rem;color:var(--text-on-dark);border-bottom:1px solid rgba(255,255,255,.05);font-weight:500}
.mobile-menu a:hover{color:var(--accent)}
.mobile-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;opacity:0;visibility:hidden;transition:all .3s}
.mobile-overlay.show{opacity:1;visibility:visible}

/* === PAGE HERO === */
.page-hero{position:relative;min-height:50vh;display:flex;align-items:center;background:var(--gradient-hero);overflow:hidden}
.page-hero-bg{position:absolute;inset:0;background-size:cover;background-position:center;opacity:.18;transition:transform .1s linear}
.page-hero-overlay{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.4) 0%,rgba(0,0,0,.15) 50%,rgba(0,0,0,.5) 100%)}
.page-hero-content{position:relative;z-index:10;max-width:1400px;margin:0 auto;padding:160px 40px 80px;width:100%}
.page-hero h1{font-size:clamp(2.5rem,5vw,4rem);color:#fff;margin-bottom:16px;letter-spacing:-0.5px;opacity:0;animation:fadeInUp .8s ease .3s forwards,shimmer 4s ease 1.5s infinite;background:linear-gradient(90deg,#fff 0%,#fff 40%,var(--shimmer-color) 50%,#fff 60%,#fff 100%);background-size:200% 100%;-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
@keyframes shimmer{0%{background-position:100% 0}100%{background-position:-100% 0}}
@keyframes fadeInUp{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
.page-hero p{color:rgba(255,255,255,.8);font-size:1.15rem;max-width:600px;opacity:0;animation:fadeInUp .8s ease .5s forwards}
.hero-particles{position:absolute;inset:0;pointer-events:none;overflow:hidden}
.cursor-spotlight{position:absolute;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,rgba(var(--particle-color),.06) 0%,transparent 70%);pointer-events:none;z-index:1;transform:translate(-50%,-50%);transition:opacity .3s}

/* === SECTION DIVIDERS === */
.section-divider{position:relative;height:80px;margin-top:-1px}
.section-divider svg{position:absolute;bottom:0;left:0;width:100%;height:80px}
.section-divider-up svg{top:0;bottom:auto;transform:rotate(180deg)}

/* === SECTIONS === */
.section{padding:100px 0;position:relative}
.section-dark{background:var(--bg-dark);color:var(--text-on-dark)}
.section-alt{background:var(--bg-alt)}
.section-light{background:var(--bg)}
.container{max-width:1400px;margin:0 auto;padding:0 40px}
.section-label{font-size:.78rem;font-weight:700;letter-spacing:3px;text-transform:uppercase;color:var(--accent);margin-bottom:16px;display:flex;align-items:center;gap:12px;padding-left:16px;border-left:4px solid var(--accent)}
.section-label::before{content:'';width:30px;height:2px;background:var(--accent)}
.section-title{font-size:clamp(2rem,3.5vw,3rem);margin-bottom:20px;color:var(--text);letter-spacing:-0.5px}
.section-title::after{content:'';display:block;width:60px;height:3px;background:var(--gradient-accent);margin-top:16px;border-radius:2px}
.section-dark .section-title{color:var(--text-on-dark)}
.section-subtitle{font-size:1.1rem;color:var(--text-light);max-width:700px;line-height:1.8}
.section-dark .section-subtitle{color:rgba(255,255,255,.7)}

/* === AS SEEN ON (large format) === */
.media-logos{display:flex;justify-content:center;align-items:center;gap:60px;flex-wrap:wrap;margin-top:50px}
.media-logo-item{text-align:center;transition:all .3s}
.media-logo-item img{height:44px;filter:grayscale(100%) opacity(.5);transition:all .4s}
.media-logo-item:hover img{filter:grayscale(0%) opacity(1);transform:scale(1.1)}
.media-logo-item span{display:block;font-size:.75rem;color:var(--text-muted);margin-top:8px;font-weight:500;letter-spacing:1px;text-transform:uppercase}
.media-logo-text{font-size:2rem!important;font-weight:800!important;letter-spacing:3px!important;color:var(--text)!important;opacity:.5;transition:opacity .4s!important;margin-top:0!important;font-family:'Inter',sans-serif!important}
.media-logo-item:hover .media-logo-text{opacity:1}

/* === FEATURED APPEARANCES === */
.appearances-grid{display:grid;grid-template-columns:1fr 1fr;gap:40px;margin-top:50px;align-items:center}
.appearance-image{border-radius:16px;overflow:hidden}
.appearance-image img{width:100%;border-radius:16px;transition:transform .6s}
.appearance-image:hover img{transform:scale(1.05)}
.appearance-image::after{content:'';position:absolute;inset:0;border-radius:16px;background:linear-gradient(135deg,transparent 50%,rgba(var(--particle-color),.1));opacity:0;transition:opacity .4s}
.appearance-image:hover::after{opacity:1}
.appearance-image{position:relative}
.appearance-content h3{font-size:1.4rem;margin-bottom:16px;color:var(--text)}
.appearance-content p{font-size:.95rem;color:var(--text-light);line-height:1.8;margin-bottom:16px}
.appearance-content .appearance-meta{font-size:.82rem;color:var(--accent);font-weight:600;letter-spacing:.5px}

/* === PODCAST === */
.podcast-section{display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center}
.podcast-info h2{margin-bottom:24px}
.podcast-info p{color:var(--text-light);margin-bottom:18px;line-height:1.8}
.podcast-features{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:24px}
.podcast-feature{display:flex;align-items:flex-start;gap:12px;padding:16px;border-radius:12px;background:var(--card-bg);border:1px solid var(--border);transition:all .3s}
.podcast-feature:hover{border-color:var(--accent);box-shadow:0 4px 20px var(--card-shadow);transform:translateY(-4px)}
.podcast-feature-icon{flex-shrink:0;color:var(--accent);margin-top:2px}
.podcast-feature h4{font-size:.95rem;font-family:'Inter',sans-serif;font-weight:600;color:var(--text);margin-bottom:4px}
.podcast-feature p{font-size:.82rem;color:var(--text-light);margin:0}
.podcast-image{border-radius:16px;overflow:hidden}
.podcast-image img{width:100%;border-radius:16px}

/* === DOCUMENT CARDS === */
.docs-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:30px;margin-top:50px}
.doc-card{background:var(--card-bg);border-radius:16px;padding:36px;box-shadow:0 4px 20px var(--card-shadow);border:1px solid var(--border);transition:all .4s;text-align:center;transform-style:preserve-3d;perspective:1000px;position:relative;overflow:hidden;backdrop-filter:blur(8px)}
.doc-card::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;background:var(--gradient-accent);transform:scaleX(0);transform-origin:left;transition:transform .4s ease}
.doc-card:hover::before{transform:scaleX(1)}
.doc-card::after{content:'';position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:linear-gradient(135deg,transparent 40%,rgba(255,255,255,.08) 50%,transparent 60%);transform:rotate(45deg) translateY(100%);transition:transform .6s ease}
.doc-card:hover::after{transform:rotate(45deg) translateY(-100%)}
.doc-card:hover{transform:translateY(-8px);box-shadow:0 20px 50px var(--card-shadow)}
.doc-card a svg{transition:transform .3s}
.doc-card a:hover svg{transform:translateY(3px)}
.doc-card-icon{width:72px;height:72px;margin:0 auto 24px;border-radius:16px;background:var(--bg-alt);display:flex;align-items:center;justify-content:center;color:var(--accent)}
.doc-card h3{font-size:1.15rem;margin-bottom:12px;color:var(--text)}
.doc-card p{font-size:.88rem;color:var(--text-light);margin-bottom:20px;line-height:1.7}
.doc-card a{display:inline-flex;align-items:center;gap:8px;color:var(--accent);font-weight:600;font-size:.88rem;padding:10px 20px;border-radius:6px;border:2px solid var(--accent);transition:all .3s}
.doc-card a:hover{background:var(--accent);color:#fff}

/* === BUTTONS === */
.btn{display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:6px;font-size:.92rem;font-weight:600;font-family:'Inter',sans-serif;cursor:pointer;border:none;transition:all .3s cubic-bezier(.4,0,.2,1);position:relative;overflow:hidden;letter-spacing:.3px}
.btn-primary{background:var(--accent);color:#fff;box-shadow:0 4px 15px rgba(201,168,76,.3)}
.btn-primary:hover{box-shadow:0 8px 30px rgba(201,168,76,.5);background:var(--accent-light);transform:translateY(-2px)}
.btn-dark{background:var(--primary);color:#fff}
.btn-dark:hover{background:var(--primary-light);box-shadow:0 8px 25px var(--card-shadow)}
.btn-submit{width:100%;justify-content:center}

/* === CTA === */
.cta-section{background:var(--gradient-hero);position:relative;overflow:hidden}
.cta-overlay{position:absolute;inset:0;background:url('https://judgemichaelwarren.com/wp-content/uploads/2026/04/maradioshowlogo-e1437763546859.png') center/cover;opacity:.12}
.cta-grid{display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:start;position:relative;z-index:2}
.cta-text{color:var(--text-on-dark)}
.cta-text h2{font-size:clamp(2rem,3vw,2.8rem);color:#fff;margin-bottom:20px}
.cta-text p{color:rgba(255,255,255,.75);margin-bottom:30px;font-size:1.05rem;line-height:1.8}
.social-links{display:flex;gap:12px}
.social-link{width:44px;height:44px;border-radius:50%;border:1px solid rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;transition:all .3s;color:rgba(255,255,255,.6)}
.social-link:hover{border-color:var(--accent);color:#fff;background:var(--accent)}
.contact-form{background:rgba(255,255,255,.05);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:40px}
.contact-form h3{color:#fff;margin-bottom:24px;font-size:1.3rem}
.form-group{margin-bottom:20px}
.form-group label{display:block;color:rgba(255,255,255,.7);font-size:.85rem;font-weight:500;margin-bottom:8px}
.form-group input,.form-group textarea{width:100%;padding:12px 16px;border-radius:8px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.05);color:#fff;font-family:'Inter',sans-serif;font-size:.92rem;transition:border-color .3s}
.form-group input::placeholder,.form-group textarea::placeholder{color:rgba(255,255,255,.35)}
.form-group input:focus,.form-group textarea:focus{outline:none;border-color:var(--accent)}
.form-group textarea{resize:vertical;min-height:120px}

/* === FOOTER === */
.footer{background:var(--bg-dark);color:rgba(255,255,255,.7);padding:80px 0 30px;position:relative;overflow:hidden}
.footer-bg-image{position:absolute;inset:0;background:url('https://judgemichaelwarren.com/wp-content/uploads/2022/07/democracy-09-scaled.jpeg') center/cover;opacity:.06}
.footer-branding{text-align:center;margin-bottom:50px;position:relative;z-index:2}
.footer-branding h2{font-size:clamp(1.8rem,3vw,2.5rem);color:var(--accent);margin-bottom:8px}
.footer-branding p{color:rgba(255,255,255,.4);font-size:.9rem;letter-spacing:2px;text-transform:uppercase}
.footer-social a{width:40px;height:40px;border-radius:50%;border:1px solid rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;transition:all .3s;color:rgba(255,255,255,.6)}
.footer-social a:hover{border-color:var(--accent);color:#fff;background:var(--accent)}
.footer-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:50px;margin-bottom:50px}
.footer-brand img{width:140px;height:140px;object-fit:cover;margin-bottom:20px;border-radius:50%;border:3px solid var(--accent);display:block;margin-left:auto;margin-right:auto}
.footer-brand p{font-size:.88rem;line-height:1.8;margin-bottom:20px}
.footer-social{display:flex;gap:12px}
.footer h4{font-family:'Inter',sans-serif;font-size:.85rem;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#fff;margin-bottom:20px}
.footer ul li{margin-bottom:10px}
.footer ul a{font-size:.88rem;color:rgba(255,255,255,.6);transition:color .3s}
.footer ul a:hover{color:var(--accent-light)}
.footer-contact-item{display:flex;gap:10px;font-size:.88rem;margin-bottom:12px;align-items:flex-start}
.footer-contact-icon{color:var(--accent);flex-shrink:0;margin-top:2px}
.footer-bottom{border-top:1px solid rgba(255,255,255,.08);padding-top:30px;display:flex;flex-direction:column;gap:12px;text-align:center}
.footer-copyright{font-size:.78rem;color:rgba(255,255,255,.3)}
.footer-credit{font-size:.75rem;color:rgba(255,255,255,.25)}
.footer-credit a{color:var(--accent);text-decoration:underline}

/* === DONATE BUTTON === */
.btn-donate{background:var(--gradient-accent);color:#fff;font-weight:700;letter-spacing:.5px;box-shadow:0 4px 15px rgba(201,168,76,.4);text-transform:uppercase;font-size:.85rem;animation:donateGlow 2s ease-in-out infinite}
.btn-donate:hover{box-shadow:0 8px 30px rgba(201,168,76,.6),0 0 20px rgba(201,168,76,.4);transform:translateY(-2px)}
@keyframes donateGlow{0%,100%{box-shadow:0 4px 15px rgba(201,168,76,.4)}50%{box-shadow:0 4px 20px rgba(201,168,76,.6),0 0 15px rgba(201,168,76,.3)}}
.nav-donate{padding:10px 24px;border-radius:6px;background:var(--gradient-accent);color:#fff!important;font-weight:700;letter-spacing:.5px;text-transform:uppercase;font-size:.82rem;box-shadow:0 2px 10px rgba(201,168,76,.3)}
.nav-donate:hover{box-shadow:0 4px 20px rgba(201,168,76,.5);transform:translateY(-1px)}
.nav-donate::after{display:none!important}

/* === PAID FOR DISCLAIMER === */
.paid-for-disclaimer{background:#0a0f1a;color:rgba(255,255,255,.7);text-align:center;padding:16px 20px;font-size:12px;font-family:'Inter',sans-serif;letter-spacing:.3px;line-height:1.5}

/* === BACK TO TOP === */
.back-to-top{position:fixed;bottom:30px;right:30px;width:48px;height:48px;border-radius:50%;background:var(--accent);color:#fff;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;opacity:0;visibility:hidden;transform:translateY(20px);transition:all .3s;z-index:9998;box-shadow:0 4px 15px rgba(0,0,0,.2)}
.back-to-top.show{opacity:1;visibility:visible;transform:translateY(0)}
.back-to-top:hover{transform:translateY(-4px);box-shadow:0 8px 25px rgba(0,0,0,.3)}

/* === COOKIE === */
.cookie-banner{position:fixed;bottom:0;left:0;right:0;background:var(--bg-dark);padding:20px 40px;z-index:99999;display:flex;align-items:center;justify-content:space-between;gap:20px;box-shadow:0 -4px 30px rgba(0,0,0,.2);transform:translateY(100%);transition:transform .4s ease;border-top:1px solid rgba(255,255,255,.08)}
.cookie-banner.show{transform:translateY(0)}
.cookie-banner p{color:rgba(255,255,255,.7);font-size:.85rem;flex:1}
.cookie-btns{display:flex;gap:10px}
.cookie-accept,.cookie-decline{padding:10px 24px;border-radius:6px;border:none;cursor:pointer;font-family:'Inter',sans-serif;font-size:.85rem;font-weight:600;transition:all .3s}
.cookie-accept{background:var(--accent);color:#fff}
.cookie-accept:hover{background:var(--accent-light)}
.cookie-decline{background:transparent;color:rgba(255,255,255,.6);border:1px solid rgba(255,255,255,.2)}
.cookie-decline:hover{border-color:rgba(255,255,255,.4);color:#fff}

/* === SCROLL REVEAL === */
.reveal{opacity:0;transform:translateY(40px);transition:all .8s cubic-bezier(.4,0,.2,1)}
.reveal.visible{opacity:1;transform:translateY(0)}
.reveal-delay-1{transition-delay:.1s}.reveal-delay-2{transition-delay:.2s}.reveal-delay-3{transition-delay:.3s}
.reveal-left{opacity:0;transform:translateX(-40px);transition:all .8s cubic-bezier(.4,0,.2,1)}
.reveal-left.visible{opacity:1;transform:translateX(0)}
.reveal-right{opacity:0;transform:translateX(40px);transition:all .8s cubic-bezier(.4,0,.2,1)}
.reveal-right.visible{opacity:1;transform:translateX(0)}

/* === RESPONSIVE === */
@media(max-width:1024px){
  .appearances-grid,.podcast-section,.cta-grid{grid-template-columns:1fr;gap:40px}
  .docs-grid{grid-template-columns:1fr;max-width:500px;margin-left:auto;margin-right:auto}
  .media-logos{gap:40px}
  .footer-grid{grid-template-columns:1fr 1fr}
  .podcast-features{grid-template-columns:1fr}
}
@media(max-width:768px){
  .nav-links{display:none}
  .hamburger{display:flex}
  .theme-switcher{position:fixed;bottom:80px;right:20px;z-index:9997;flex-direction:column;background:var(--bg-dark);border:1px solid rgba(255,255,255,.15);box-shadow:0 4px 20px rgba(0,0,0,.3)}
  .section{padding:60px 0}
  .container{padding:0 20px}
  .nav-inner{padding:0 20px}
  .media-logos{gap:30px}
  .media-logo-item img{height:36px}
  .footer-grid{grid-template-columns:1fr;gap:30px}
  .cookie-banner{flex-direction:column;text-align:center}
  .page-hero-content{padding:140px 20px 60px}
}
@media print{
  .nav,.back-to-top,.cookie-banner,.scroll-progress,.loader-screen,.theme-switcher,.hero-particles,.cursor-spotlight{display:none!important}
  .page-hero{min-height:auto;background:#fff!important;color:#000!important}
  .page-hero h1{-webkit-text-fill-color:#000!important}
  body{font-size:12pt}
  .section-dark{background:#fff!important;color:#000!important}
  .cta-section{background:#fff!important}
  .cta-text,.cta-text h2,.cta-text p{color:#000!important}
  .footer{background:#fff!important;color:#000!important}
}
</style>
<?php wp_head(); ?>
</head>
<body>
<a href="#main-content" class="skip-link">Skip to main content</a>

<!-- Loading Screen -->
<div class="loader-screen" id="loader">
  <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Logo-For-Judge-Warren.png" alt="Warren for Michigan Supreme Court" class="loader-logo">
  <div class="loader-bar"></div>
</div>

<!-- Scroll Progress -->
<div class="scroll-progress" id="scrollProgress"></div>

<!-- Navigation -->
<nav class="nav" id="navbar" role="navigation" aria-label="Main navigation">
  <div class="nav-inner">
    <a href="<?php echo home_url('/'); ?>" class="nav-logo" aria-label="Warren for Michigan Supreme Court Home">
      <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Logo-For-Judge-Warren.png" alt="Warren for Michigan Supreme Court" id="navLogo">
    </a>
    <div class="nav-links">
      <a href="<?php echo home_url('/'); ?>">Home</a>
      <a href="<?php echo home_url('/about/'); ?>">About</a>
      <a href="<?php echo home_url('/media-appearances/'); ?>" class="active">Media</a>
      <a href="https://secure.anedot.com/michael-warren-for-supreme-court/donate" class="nav-donate" target="_blank" rel="noopener">Donate</a>
    </div>

    <button class="hamburger" id="hamburger" aria-label="Toggle menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>
<div class="mobile-overlay" id="mobileOverlay"></div>
<div class="mobile-menu" id="mobileMenu" role="navigation" aria-label="Mobile navigation">
  <a href="<?php echo home_url('/'); ?>">Home</a>
  <a href="<?php echo home_url('/about/'); ?>">About</a>
  <a href="<?php echo home_url('/media-appearances/'); ?>">Media</a>
  <a href="https://secure.anedot.com/michael-warren-for-supreme-court/donate" style="color:var(--accent);font-weight:700">Donate</a>
</div>

<main id="main-content">

<!-- Page Hero -->
<section class="page-hero" id="heroSection">
  <div class="page-hero-bg" id="heroBg" style="background-image:url('https://judgemichaelwarren.com/wp-content/uploads/2022/01/IMG_9303-scaled.jpg')"></div>
  <div class="page-hero-overlay"></div>
  <div class="hero-particles" id="heroParticles"></div>
  <div class="cursor-spotlight" id="heroSpotlight" style="opacity:0;"></div>
  <div class="page-hero-content">
    <h1>Media &amp; Opinions</h1>
    <p>Explore Judge Warren's media appearances, publications, podcast, and the documents that define his judicial philosophy and public service.</p>
  </div>
</section>

<!-- Section Divider -->
<div class="section-divider"><svg viewBox="0 0 1440 80" preserveAspectRatio="none"><path fill="var(--bg-alt)" d="M0,0 L0,40 Q360,80 720,40 Q1080,0 1440,40 L1440,80 L0,80 Z"/></svg></div>

<!-- Featured Appearances -->
<section class="section section-alt" id="appearances">
  <div class="container">
    <div class="reveal" style="margin-bottom:20px">
      <p class="section-label">Featured Appearances</p>
      <h2 class="section-title">In the Spotlight</h2>
    </div>
    <div class="appearances-grid">
      <div class="appearance-image reveal-left">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/maradioshowlogo-e1437763546859.png" alt="The Mitch Albom Show" style="object-fit:contain;padding:30px;background:#fff" loading="lazy">
      </div>
      <div class="appearance-content reveal-right">
        <h3>The Mitch Albom Show</h3>
        <p>Judge Warren has been a featured guest on The Mitch Albom Show, one of Michigan's most influential talk radio programs. His conversations with Albom explore constitutional law, American history, the importance of civic education, and the principles that sustain our republic.</p>
        <p>These appearances have reached hundreds of thousands of listeners across Michigan and beyond, sparking meaningful conversations about the role of the judiciary and the importance of constitutional literacy.</p>
        <div class="appearance-meta">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:6px"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>
          Radio &amp; Podcast &mdash; WJR 760 AM, Detroit
        </div>
      </div>
    </div>
    <div class="appearances-grid" style="margin-top:60px">
      <div class="appearance-content reveal-left">
        <h3>National Press Coverage</h3>
        <p>Judge Warren's induction into the International Association of Top Professionals (IAOTP) Hall of Fame generated significant national press coverage, with features appearing across ABC, CBS, FOX, NBC, and CW affiliate stations.</p>
        <p>His work with Patriot Week &mdash; a national celebration of American founding principles &mdash; has similarly attracted national media attention, elevating the conversation about civic education and constitutional literacy in America.</p>
        <div class="appearance-meta">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:6px"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
          National Television &amp; Digital Media
        </div>
      </div>
      <div class="appearance-image reveal-right">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2022/07/IMG_6684-min-min.jpg" alt="Judge Warren press coverage" loading="lazy">
      </div>
    </div>

    <!-- Fox 2 Detroit -->
    <div class="appearances-grid" style="margin-top:60px">
      <div class="appearance-image reveal-left">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Book.jpg" alt="Judge Warren on Fox 2 Detroit" loading="lazy">
      </div>
      <div class="appearance-content reveal-right">
        <h3>Fox 2 Detroit</h3>
        <p>Judge Warren appeared on Fox 2 Detroit discussing constitutional principles, the rule of law, and his vision for Michigan's judicial future. As a candidate for Michigan Supreme Court, he brings more trial experience than the entire current Supreme Court combined.</p>
        <div class="appearance-meta">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:6px"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>
          <a href="https://www.fox2detroit.com/video/fmc-xavzoikt2k6bll6m" target="_blank" rel="noopener" style="color:var(--accent);font-weight:600">Watch on Fox 2 Detroit &rarr;</a>
        </div>
      </div>
    </div>

    <!-- Steve Gruber Show -->
    <div class="appearances-grid" style="margin-top:60px">
      <div class="appearance-content reveal-left">
        <h3>The Steve Gruber Show</h3>
        <p>Judge Warren joined The Steve Gruber Show to discuss what history teaches us about the present &mdash; drawing on his deep knowledge of constitutional law and American founding principles. A powerful conversation about defending the Constitution and the importance of judicial integrity.</p>
        <div class="appearance-meta">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:6px"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>
          <a href="https://rumble.com/v77xaf4-what-history-teaches-us-now-with-judge-michael-warren.html" target="_blank" rel="noopener" style="color:var(--accent);font-weight:600">Watch on Rumble &rarr;</a>
        </div>
      </div>
      <div class="appearance-image reveal-right">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Steve-Gruber.jpg" alt="Steve Gruber Show" loading="lazy">
      </div>
    </div>
  </div>
</section>

<!-- Patriot Lessons Podcast & TV -->
<section class="section section-light" id="podcast">
  <div class="container">
    <div class="podcast-section">
      <div class="podcast-info reveal-left">
        <p class="section-label">Podcast &amp; TV Show</p>
        <h2 class="section-title">Patriot Lessons</h2>
        <p>Judge Warren hosts the Patriot Lessons podcast and TV show &mdash; an engaging exploration of the Constitution, American history, and the principles that preserve liberty for future generations.</p>
        <p>Each episode dives deep into the ideas that animated the founding generation, drawing connections between historical events and contemporary challenges to American governance and civil liberties.</p>
        <div class="podcast-features">
          <div class="podcast-feature" data-tilt>
            <div class="podcast-feature-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
            </div>
            <div>
              <h4>Constitutional Deep Dives</h4>
              <p>Exploring the text and meaning of the Constitution</p>
            </div>
          </div>
          <div class="podcast-feature" data-tilt>
            <div class="podcast-feature-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>
            </div>
            <div>
              <h4>Video Episodes</h4>
              <p>Available on YouTube and television broadcast</p>
            </div>
          </div>
          <div class="podcast-feature" data-tilt>
            <div class="podcast-feature-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
            <div>
              <h4>Expert Guests</h4>
              <p>Featuring scholars, historians, and civic leaders</p>
            </div>
          </div>
          <div class="podcast-feature" data-tilt>
            <div class="podcast-feature-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            </div>
            <div>
              <h4>Patriot Week Specials</h4>
              <p>Special episodes celebrating American First Principles</p>
            </div>
          </div>
        </div>
      </div>
      <div class="podcast-image reveal-right">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2022/01/IMG_9303-scaled.jpg" alt="Judge Warren Patriot Lessons" loading="lazy">
      </div>
    </div>
  </div>
</section>

<!-- Documents & Downloads -->
<section class="section section-alt" id="documents">
  <div class="container">
    <div class="reveal" style="text-align:center;margin-bottom:20px">
      <p class="section-label" style="justify-content:center">Documents &amp; Downloads</p>
      <h2 class="section-title">Official Publications</h2>
      <p class="section-subtitle" style="margin:0 auto">Access Judge Warren's official documents, including his comprehensive resume, judicial philosophy statement, and Hall of Fame press release.</p>
    </div>
    <div class="docs-grid">
      <div class="doc-card reveal reveal-delay-1" data-tilt>
        <div class="doc-card-icon">
          <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
        </div>
        <h3>Resume / CV</h3>
        <p>Comprehensive curriculum vitae detailing Judge Warren's education, judicial career, awards, publications, and public service record.</p>
        <a href="https://judgemichaelwarren.com/wp-content/uploads/2022/02/Supreme-Court-Campaign-2022-CV-FINAL.pdf" target="_blank" rel="noopener">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>
          Download PDF
        </a>
      </div>
      <div class="doc-card reveal reveal-delay-2" data-tilt>
        <div class="doc-card-icon">
          <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v18M3 7l9-4 9 4M3 7l3 6h6L9 7M15 7l3 6h6l-3-6"/></svg>
        </div>
        <h3>Judicial Philosophy</h3>
        <p>Judge Warren's statement of judicial philosophy &mdash; his commitment to textualism, originalism, and the faithful application of the law as written.</p>
        <a href="https://judgemichaelwarren.com/wp-content/uploads/2022/03/Judicial-Philosphy-Warren-COA.pdf" target="_blank" rel="noopener">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>
          Download PDF
        </a>
      </div>
      <div class="doc-card reveal reveal-delay-3" data-tilt>
        <div class="doc-card-icon">
          <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>
        </div>
        <h3>Hall of Fame Press Release</h3>
        <p>Official press release announcing Judge Warren's induction into the International Association of Top Professionals Hall of Fame.</p>
        <a href="https://judgemichaelwarren.com/wp-content/uploads/2022/10/PR-Distribution-stephanie-cirami-Judge-Michael-Warren-inducted-into-IAOTPs-Hall-of-Fame-P1-Bonus-A.pdf" target="_blank" rel="noopener">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>
          Download PDF
        </a>
      </div>
    </div>
  </div>
</section>

<!-- Get Involved CTA -->
<section class="section cta-section" id="contact">
  <div class="cta-overlay"></div>
  <div class="cursor-spotlight" id="ctaSpotlight" style="opacity:0;"></div>
  <div class="container">
    <div class="cta-grid">
      <div class="cta-text reveal-left">
        <p class="section-label" style="color:var(--accent-light)">Get Involved</p>
        <h2>We Win With Warren!</h2>
        <p>On November 3rd, 2026 &mdash; Vote Michael Warren for Michigan Supreme Court. Whether you want to learn more, donate, invite him to speak, or simply connect &mdash; reach out. Every voice matters in the fight to preserve our constitutional republic.</p>
        <a href="https://secure.anedot.com/michael-warren-for-supreme-court/donate" class="btn btn-donate" target="_blank" rel="noopener" style="margin-bottom:20px">Donate to the Campaign</a>
        <div class="social-links">
          <a href="https://www.facebook.com/WarrenforMI" target="_blank" rel="noopener" class="social-link" aria-label="Facebook"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
          <a href="https://www.instagram.com/judgewarrenforMI" target="_blank" rel="noopener" class="social-link" aria-label="Instagram"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a>
          <a href="https://www.youtube.com/@judgemichaelwarren" target="_blank" rel="noopener" class="social-link" aria-label="YouTube"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19.13C5.12 19.56 12 19.56 12 19.56s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.43z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"/></svg></a>
          <a href="https://x.com/warrenformi" target="_blank" rel="noopener" class="social-link" aria-label="X/Twitter"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg></a>
        </div>
      </div>
      <div class="contact-form reveal-right">
        <h3>Send a Message</h3>
        <form onsubmit="event.preventDefault();this.querySelector('.btn-submit').textContent='Message Sent!';this.reset();">
          <div class="form-group">
            <label for="name">Your Name</label>
            <input type="text" id="name" placeholder="John Smith" required>
          </div>
          <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" placeholder="john@example.com" required>
          </div>
          <div class="form-group">
            <label for="message">Message</label>
            <textarea id="message" placeholder="How can we help?" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-submit">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
            Send Message
          </button>
        </form>
      </div>
    </div>
  </div>
</section>

</main>

<!-- Footer -->
<footer class="footer" role="contentinfo">
  <div class="footer-bg-image"></div>
  <div class="container" style="position:relative;z-index:2">
    <div class="footer-branding">
      <h2>Warren for Michigan Supreme Court</h2>
      <p>Defending the Constitution &amp; the Rule of Law</p>
    </div>
    <div class="footer-grid">
      <div class="footer-brand">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Judge-Warren-Picture.jpg" alt="Judge Michael Warren" loading="lazy">
        <p>Judge Michael Warren &mdash; Candidate for Michigan Supreme Court. Defender of the Constitution with 400+ jury trials, constitutional law professor, author, Patriot Week co-founder. We Win With Warren!</p>
        <div class="footer-social">
          <a href="https://www.facebook.com/WarrenforMI" target="_blank" rel="noopener" aria-label="Facebook"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
          <a href="https://www.instagram.com/judgewarrenforMI" target="_blank" rel="noopener" aria-label="Instagram"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a>
          <a href="https://www.youtube.com/@judgemichaelwarren" target="_blank" rel="noopener" aria-label="YouTube"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19.13C5.12 19.56 12 19.56 12 19.56s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.43z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"/></svg></a>
          <a href="https://x.com/warrenformi" target="_blank" rel="noopener" aria-label="X/Twitter"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg></a>
        </div>
      </div>
      <div>
        <h4>Quick Links</h4>
        <ul>
          <li><a href="<?php echo home_url('/'); ?>">Home</a></li>
          <li><a href="<?php echo home_url('/about/'); ?>">About</a></li>
          <li><a href="<?php echo home_url('/media-appearances/'); ?>">Media</a></li>
        </ul>
      </div>
      <div>
        <h4>Resources</h4>
        <ul>
          <li><a href="https://www.amazon.com/Americas-Survival-Guide-Michael-Warren/dp/1934248312" target="_blank" rel="noopener">America's Survival Guide</a></li>
          <li><a href="https://www.PatriotWeek.org" target="_blank" rel="noopener">Patriot Week</a></li>
          <li><a href="#podcast">Patriot Lessons</a></li>
        </ul>
      </div>
      <div>
        <h4>Contact</h4>
        <div class="footer-contact-item">
          <span class="footer-contact-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg></span>
          <a href="mailto:info@judgemichaelwarren.com">info@judgemichaelwarren.com</a>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <p class="footer-copyright">&copy; 2026 Judge Michael Warren. All rights reserved.</p>
      <p class="footer-credit">Built by <a href="https://kirkautomations.com" target="_blank" rel="noopener">Kirk Automations</a></p>
    </div>
  </div>
</footer>

<!-- Back to Top -->
<button class="back-to-top" id="backToTop" aria-label="Back to top">
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg>
</button>

<!-- Cookie Consent -->
<div class="cookie-banner" id="cookieBanner" role="dialog" aria-label="Cookie consent">
  <p>We use cookies to enhance your browsing experience and analyze site traffic. By continuing, you agree to our use of cookies.</p>
  <div class="cookie-btns">
    <button class="cookie-accept" id="cookieAccept">Accept</button>
    <button class="cookie-decline" id="cookieDecline">Decline</button>
  </div>
</div>

<script>
(function(){
  'use strict';
  var loader=document.getElementById('loader');
  if(loader){if(sessionStorage.getItem('warren-loaded')){loader.classList.add('hidden')}else{setTimeout(function(){loader.classList.add('hidden');sessionStorage.setItem('warren-loaded','1')},1800)}}



  var nav=document.getElementById('navbar');
  window.addEventListener('scroll',function(){
    var scrollY=window.scrollY;
    if(nav)nav.classList.toggle('scrolled',scrollY>80);
    var progress=document.getElementById('scrollProgress');
    if(progress){var docH=document.documentElement.scrollHeight-window.innerHeight;progress.style.width=docH>0?(scrollY/docH*100)+'%':'0%'}
    var btt=document.getElementById('backToTop');
    if(btt)btt.classList.toggle('show',scrollY>500);
  },{passive:true});

  var btt=document.getElementById('backToTop');
  if(btt)btt.addEventListener('click',function(){window.scrollTo({top:0,behavior:'smooth'})});

  var hamburger=document.getElementById('hamburger'),mobileMenu=document.getElementById('mobileMenu'),mobileOverlay=document.getElementById('mobileOverlay');
  if(hamburger&&mobileMenu&&mobileOverlay){
    var toggleMenu=function(){var open=mobileMenu.classList.toggle('open');hamburger.classList.toggle('active');mobileOverlay.classList.toggle('show');hamburger.setAttribute('aria-expanded',open);document.body.style.overflow=open?'hidden':''};
    hamburger.addEventListener('click',toggleMenu);mobileOverlay.addEventListener('click',toggleMenu);
    mobileMenu.querySelectorAll('a').forEach(function(a){a.addEventListener('click',function(){if(mobileMenu.classList.contains('open'))toggleMenu()})});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&mobileMenu.classList.contains('open'))toggleMenu()});
  }

  var cookieBanner=document.getElementById('cookieBanner');
  if(cookieBanner&&!localStorage.getItem('warren-cookies')){setTimeout(function(){cookieBanner.classList.add('show')},2500)}
  var ca=document.getElementById('cookieAccept');if(ca)ca.addEventListener('click',function(){localStorage.setItem('warren-cookies','accepted');cookieBanner.classList.remove('show')});
  var cd=document.getElementById('cookieDecline');if(cd)cd.addEventListener('click',function(){localStorage.setItem('warren-cookies','declined');cookieBanner.classList.remove('show')});

  var reveals=document.querySelectorAll('.reveal,.reveal-left,.reveal-right');
  if('IntersectionObserver' in window){
    var observer=new IntersectionObserver(function(entries){entries.forEach(function(entry){if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target)}})},{threshold:0.1,rootMargin:'0px 0px -50px 0px'});
    reveals.forEach(function(el){observer.observe(el)});
  }else{reveals.forEach(function(el){el.classList.add('visible')})}

  document.querySelectorAll('[data-tilt]').forEach(function(card){
    card.addEventListener('mousemove',function(e){var rect=card.getBoundingClientRect();var x=(e.clientX-rect.left)/rect.width-0.5;var y=(e.clientY-rect.top)/rect.height-0.5;card.style.transform='perspective(1000px) rotateY('+x*8+'deg) rotateX('+-y*8+'deg) translateY(-8px)'});
    card.addEventListener('mouseleave',function(){card.style.transform=''});
  });

  document.querySelectorAll('.btn').forEach(function(btn){
    btn.addEventListener('mousemove',function(e){var rect=btn.getBoundingClientRect();var x=e.clientX-rect.left-rect.width/2;var y=e.clientY-rect.top-rect.height/2;btn.style.transform='translate('+x*0.15+'px,'+y*0.15+'px)'});
    btn.addEventListener('mouseleave',function(){btn.style.transform=''});
  });

  function setupSpotlight(sectionId,spotlightId){
    var section=document.getElementById(sectionId);var spot=document.getElementById(spotlightId);if(!section||!spot)return;
    section.addEventListener('mousemove',function(e){var rect=section.getBoundingClientRect();spot.style.left=(e.clientX-rect.left)+'px';spot.style.top=(e.clientY-rect.top)+'px';spot.style.opacity='1'});
    section.addEventListener('mouseleave',function(){spot.style.opacity='0'});
  }
  setupSpotlight('heroSection','heroSpotlight');
  setupSpotlight('contact','ctaSpotlight');

  var heroParticles=document.getElementById('heroParticles'),heroSection=document.getElementById('heroSection');
  if(heroParticles&&heroSection){
    var particleCount=0;
    heroSection.addEventListener('mousemove',function(e){
      if(particleCount>30||window.innerWidth<768)return;
      var rect=heroSection.getBoundingClientRect();var particle=document.createElement('div');particleCount++;var size=Math.random()*5+2;
      particle.style.cssText='position:absolute;left:'+(e.clientX-rect.left)+'px;top:'+(e.clientY-rect.top)+'px;width:'+size+'px;height:'+size+'px;border-radius:50%;background:rgba(var(--particle-color),'+(Math.random()*0.5+0.3)+');pointer-events:none;transition:all 1s ease;z-index:5';
      heroParticles.appendChild(particle);
      requestAnimationFrame(function(){particle.style.transform='translate('+(Math.random()-0.5)*80+'px,'+(Math.random()-0.5)*80+'px)';particle.style.opacity='0'});
      setTimeout(function(){particle.remove();particleCount--},1000);
    });
  }

  var heroBg=document.getElementById('heroBg');
  window.addEventListener('scroll',function(){if(heroBg)heroBg.style.transform='translateY('+window.scrollY*0.3+'px)'},{passive:true});

  document.querySelectorAll('a[href^="#"]').forEach(function(a){a.addEventListener('click',function(e){var target=document.querySelector(a.getAttribute('href'));if(target){e.preventDefault();target.scrollIntoView({behavior:'smooth'})}})});
})();
</script>

<!-- Paid For Disclaimer &mdash; Legal Requirement -->
<div class="paid-for-disclaimer">
  Paid for by Michael Warren for Supreme Court &bull; PO Box 1182 &bull; Brighton, MI 48116
</div>

<?php wp_footer(); ?>
</body>
</html>ull; Brighton, MI 48116
</div>

<?php wp_footer(); ?>
</body>
</html>