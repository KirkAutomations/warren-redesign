<?php
/*
Template Name: About Page
*/
?>
<!DOCTYPE html>
<html lang="en" data-theme="patriot">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Judge Michael Warren | Warren for Michigan Supreme Court</title>
<meta name="description" content="Learn about Judge Michael Warren &mdash; Candidate for Michigan Supreme Court. Defender of the Constitution with 400+ jury trials, constitutional law professor, author, and champion of American First Principles.">
<meta name="keywords" content="Judge Michael Warren, biography, Michigan Supreme Court, constitutional law, career timeline, judicial philosophy, Warren for Supreme Court">
<meta property="og:title" content="About Judge Michael Warren | Warren for Michigan Supreme Court">
<meta property="og:description" content="Candidate for Michigan Supreme Court. 400+ jury trials, constitutional law professor, author, and defender of American principles. We Win With Warren!">
<meta property="og:image" content="https://judgemichaelwarren.com/wp-content/uploads/2022/01/Michael_D._Warren_Jr._Fixed.png">
<meta property="og:url" content="https://judgemichaelwarren.com/about">
<meta property="og:type" content="profile">
<meta name="twitter:card" content="summary_large_image">
<link rel="canonical" href="https://judgemichaelwarren.com/about">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "Judge Michael Warren",
  "jobTitle": "Candidate for Michigan Supreme Court",
  "description": "Candidate for Michigan Supreme Court. Defender of the Constitution with 400+ jury trials, constitutional law professor, and author.",
  "url": "https://judgemichaelwarren.com",
  "image": "https://judgemichaelwarren.com/wp-content/uploads/2022/01/Michael_D._Warren_Jr._Fixed.png",
  "email": "info@judgemichaelwarren.com",
  "alumniOf": [
    {"@type": "CollegeOrUniversity", "name": "University of Michigan Law School"},
    {"@type": "CollegeOrUniversity", "name": "Wayne State University"}
  ],
  "award": ["Judge of the Decade (IAOTP)", "Distinguished Public Servant Award (OCBA)", "IAOTP Hall of Fame"]
}
</script>
<style>
/* === RESET & BASE === */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;font-size:16px}
body{font-family:'Inter',-apple-system,BlinkMacSystemFont,sans-serif;line-height:1.7;overflow-x:hidden;-webkit-font-smoothing:antialiased}
a{text-decoration:none;color:inherit;transition:color .3s}
img{max-width:100%;height:auto;display:block}
ul,ol{list-style:none}
h1,h2,h3,h4,h5,h6{font-family:'Playfair Display',Georgia,serif;line-height:1.2;font-weight:700}
.skip-link{position:absolute;top:-100%;left:50%;transform:translateX(-50%);background:var(--accent);color:#fff;padding:12px 24px;z-index:100000;border-radius:0 0 8px 8px;font-weight:600}
.skip-link:focus{top:0}

/* === THEMES === */
[data-theme="patriot"]{--primary:#1a2744;--primary-dark:#0f1a30;--primary-light:#2a3d60;--accent:#c9a84c;--accent-light:#dbc070;--accent-dark:#a88a35;--bg:#ffffff;--bg-alt:#f5f5f7;--bg-dark:#0f1a30;--text:#1a1a2e;--text-light:#555;--text-on-dark:#ffffff;--text-muted:#888;--card-bg:#ffffff;--card-shadow:rgba(26,39,68,0.08);--nav-bg:rgba(26,39,68,0.95);--nav-scrolled:rgba(15,26,48,0.97);--border:rgba(26,39,68,0.1);--gradient-hero:linear-gradient(135deg,#0f1a30 0%,#1a2744 50%,#2a3d60 100%);--gradient-accent:linear-gradient(135deg,#c9a84c,#dbc070);--shimmer-color:#c9a84c;--particle-color:201,168,76;--glass-card:rgba(255,255,255,0.7);--glass-card-border:rgba(255,255,255,0.3)}
[data-theme="constitution"]{--primary:#1c1c2e;--primary-dark:#111120;--primary-light:#2d2d4a;--accent:#8b2332;--accent-light:#a83545;--accent-dark:#6e1a27;--bg:#f4f0e8;--bg-alt:#ebe5d8;--bg-dark:#111120;--text:#1c1c2e;--text-light:#555;--text-on-dark:#e8e0d0;--text-muted:#888;--card-bg:#faf6ee;--card-shadow:rgba(28,28,46,0.08);--nav-bg:rgba(28,28,46,0.95);--nav-scrolled:rgba(17,17,32,0.97);--border:rgba(28,28,46,0.1);--gradient-hero:linear-gradient(135deg,#111120 0%,#1c1c2e 50%,#2d2d4a 100%);--gradient-accent:linear-gradient(135deg,#8b2332,#a83545);--shimmer-color:#d4c5a0;--particle-color:212,197,160;--glass-card:rgba(250,246,238,0.7);--glass-card-border:rgba(250,246,238,0.3)}
[data-theme="liberty"]{--primary:#1a2744;--primary-dark:#0f1a30;--primary-light:#2a3d60;--accent:#c9a84c;--accent-light:#dbc070;--accent-dark:#a88a35;--bg:#faf8f3;--bg-alt:#f0ede4;--bg-dark:#1a2744;--text:#1a2744;--text-light:#4a5568;--text-on-dark:#faf8f3;--text-muted:#718096;--card-bg:#ffffff;--card-shadow:rgba(26,39,68,0.06);--nav-bg:rgba(250,248,243,0.95);--nav-scrolled:rgba(250,248,243,0.98);--border:rgba(26,39,68,0.08);--gradient-hero:linear-gradient(135deg,#1a2744 0%,#2a3d60 50%,#3a5080 100%);--gradient-accent:linear-gradient(135deg,#c9a84c,#dbc070);--shimmer-color:#c9a84c;--particle-color:201,168,76;--glass-card:rgba(255,255,255,0.7);--glass-card-border:rgba(255,255,255,0.3)}

/* === LOADING SCREEN === */
.loader-screen{position:fixed;top:0;left:0;width:100%;height:100%;background:var(--bg-dark);display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:999999;transition:opacity .6s ease,visibility .6s ease}
.loader-screen.hidden{opacity:0;visibility:hidden;pointer-events:none}
.loader-logo{width:280px;opacity:0;animation:loaderFade 1.5s ease forwards}
@keyframes loaderFade{0%{opacity:0;transform:scale(.9)}50%{opacity:1;transform:scale(1.02)}100%{opacity:1;transform:scale(1)}}
.loader-bar{position:absolute;bottom:40%;left:50%;transform:translateX(-50%);width:200px;height:2px;background:rgba(255,255,255,.1);border-radius:2px;overflow:hidden}
.loader-bar::after{content:'';position:absolute;left:0;top:0;height:100%;width:0;background:var(--gradient-accent);animation:loaderProgress 1.5s ease forwards}
@keyframes loaderProgress{to{width:100%}}

/* === SCROLL PROGRESS === */
.scroll-progress{position:fixed;top:0;left:0;height:3px;background:var(--gradient-accent);width:0%;z-index:100001;transition:width .1s linear}

/* === NAVIGATION === */
.nav{position:fixed;top:0;left:0;right:0;z-index:10000;padding:18px 0;background:transparent;transition:all .4s cubic-bezier(.4,0,.2,1)}
.nav.scrolled{padding:10px 0;background:var(--nav-scrolled);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);box-shadow:0 2px 30px rgba(0,0,0,.15)}
[data-theme="liberty"] .nav{background:transparent}
[data-theme="liberty"] .nav.scrolled{background:var(--nav-scrolled);box-shadow:0 1px 20px rgba(0,0,0,.06)}
.nav-inner{max-width:1400px;margin:0 auto;padding:0 40px;display:flex;align-items:center;justify-content:space-between}
.nav-logo img{height:56px;transition:height .3s;filter:brightness(1.8) contrast(1.1) drop-shadow(0 0 8px rgba(255,255,255,.5))}
.nav.scrolled .nav-logo img{height:44px}
.nav-links{display:flex;gap:32px;align-items:center}
.nav-links a{font-size:.88rem;font-weight:500;letter-spacing:.3px;color:var(--text-on-dark);position:relative;padding:4px 0;transition:color .3s}
[data-theme="liberty"] .nav-links a{color:var(--text)}
.nav-links a::after{content:'';position:absolute;bottom:-2px;left:0;width:0;height:2px;background:var(--accent);transition:width .3s ease}
.nav-links a:hover::after,.nav-links a.active::after{width:100%}
.nav-links a:hover{color:var(--accent-light)}
.theme-switcher{display:flex;background:rgba(255,255,255,.12);border-radius:30px;padding:3px;border:1px solid rgba(255,255,255,.2);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);box-shadow:0 4px 15px rgba(0,0,0,.1)}
[data-theme="liberty"] .theme-switcher{background:rgba(0,0,0,.06);border-color:rgba(0,0,0,.12);box-shadow:0 4px 15px rgba(0,0,0,.05)}
.theme-btn{padding:5px 14px;border-radius:25px;border:none;cursor:pointer;font-size:.72rem;font-weight:600;font-family:'Inter',sans-serif;background:transparent;color:rgba(255,255,255,.6);transition:all .3s;letter-spacing:.5px}
[data-theme="liberty"] .theme-btn{color:rgba(0,0,0,.4)}
.theme-btn.active{background:var(--accent);color:#fff;box-shadow:0 2px 10px rgba(0,0,0,.2)}
.theme-btn:hover:not(.active){color:#fff;background:rgba(255,255,255,.15)}
[data-theme="liberty"] .theme-btn:hover:not(.active){color:var(--text);background:rgba(0,0,0,.08)}
.hamburger{display:none;flex-direction:column;gap:5px;cursor:pointer;padding:8px;z-index:10001;background:none;border:none}
.hamburger span{display:block;width:24px;height:2px;background:var(--text-on-dark);transition:all .3s;border-radius:2px}
[data-theme="liberty"] .hamburger span{background:var(--text)}
.hamburger.active span:nth-child(1){transform:rotate(45deg) translate(5px,5px)}
.hamburger.active span:nth-child(2){opacity:0}
.hamburger.active span:nth-child(3){transform:rotate(-45deg) translate(5px,-5px)}
.mobile-menu{position:fixed;top:0;right:-100%;width:320px;height:100vh;background:var(--bg-dark);z-index:10000;padding:100px 40px 40px;transition:right .4s cubic-bezier(.4,0,.2,1);box-shadow:-10px 0 40px rgba(0,0,0,.3)}
.mobile-menu.open{right:0}
.mobile-menu a{display:block;padding:16px 0;font-size:1.1rem;color:var(--text-on-dark);border-bottom:1px solid rgba(255,255,255,.05);font-weight:500}
.mobile-menu a:hover{color:var(--accent)}
.mobile-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;opacity:0;visibility:hidden;transition:all .3s}
.mobile-overlay.show{opacity:1;visibility:visible}

/* === PAGE HERO BANNER === */
.page-hero{position:relative;min-height:50vh;display:flex;align-items:center;background:var(--gradient-hero);overflow:hidden}
.page-hero-bg{position:absolute;inset:0;background-size:cover;background-position:center;opacity:.18;transition:transform .1s linear}
.page-hero-overlay{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.4) 0%,rgba(0,0,0,.2) 100%)}
.page-hero-content{position:relative;z-index:10;max-width:1400px;margin:0 auto;padding:160px 40px 80px;width:100%}
.page-hero h1{font-size:clamp(2.5rem,5vw,4rem);color:#fff;margin-bottom:16px;letter-spacing:-0.5px;opacity:0;animation:fadeInUp .8s ease .3s forwards,shimmer 4s ease 1.5s infinite;background:linear-gradient(90deg,#fff 0%,#fff 40%,var(--shimmer-color) 50%,#fff 60%,#fff 100%);background-size:200% 100%;-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
@keyframes shimmer{0%{background-position:100% 0}100%{background-position:-100% 0}}
@keyframes fadeInUp{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
.page-hero p{color:rgba(255,255,255,.8);font-size:1.15rem;max-width:600px;opacity:0;animation:fadeInUp .8s ease .5s forwards}
.hero-particles{position:absolute;inset:0;pointer-events:none;overflow:hidden}
.cursor-spotlight{position:absolute;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,rgba(var(--particle-color),.06) 0%,transparent 70%);pointer-events:none;z-index:1;transform:translate(-50%,-50%);transition:opacity .3s}

/* === SECTIONS === */
.section{padding:100px 0;position:relative}
.section-dark{background:var(--bg-dark);color:var(--text-on-dark)}
.section-alt{background:var(--bg-alt)}
.section-light{background:var(--bg)}
.container{max-width:1400px;margin:0 auto;padding:0 40px}

/* Section Label &mdash; Gold Left Border */
.section-label{font-size:.78rem;font-weight:700;letter-spacing:3px;text-transform:uppercase;color:var(--accent);margin-bottom:16px;display:inline-flex;align-items:center;gap:12px;border-left:4px solid var(--accent);padding-left:14px}
.section-label::before{display:none}

/* Section Title &mdash; Gold Underline Bar + Tight Spacing */
.section-title{font-size:clamp(2rem,3.5vw,3rem);margin-bottom:20px;color:var(--text);letter-spacing:-0.5px;position:relative;display:inline-block}
.section-title::after{content:'';display:block;width:60px;height:4px;background:var(--gradient-accent);border-radius:2px;margin-top:12px}
.section-dark .section-title{color:var(--text-on-dark)}
.section-subtitle{font-size:1.1rem;color:var(--text-light);max-width:700px;line-height:1.8}
.section-dark .section-subtitle{color:rgba(255,255,255,.7)}

/* Section Dividers */
.section-divider{position:relative;height:60px;margin-top:-1px;overflow:hidden}

/* === BIOGRAPHY === */
.bio-grid{display:grid;grid-template-columns:1fr 1.2fr;gap:60px;align-items:start}
.bio-image{position:relative;border-radius:16px;overflow:hidden}
.bio-image img{width:100%;border-radius:16px;box-shadow:0 20px 50px var(--card-shadow)}
.bio-image::after{content:'';position:absolute;inset:0;border-radius:16px;border:2px solid var(--accent);top:20px;left:20px;right:-20px;bottom:-20px;z-index:-1;opacity:.3}
.bio-content h2{margin-bottom:24px}
.bio-content p{color:var(--text-light);margin-bottom:18px;font-size:.95rem;line-height:1.8}

/* === TIMELINE === */
.timeline{position:relative;max-width:900px;margin:50px auto 0;padding-left:40px}
.timeline::before{content:'';position:absolute;left:15px;top:0;bottom:0;width:2px;background:var(--border)}
.timeline-item{position:relative;margin-bottom:40px;padding-left:40px}
.timeline-item::before{content:'';position:absolute;left:-29px;top:8px;width:14px;height:14px;border-radius:50%;background:var(--accent);border:3px solid var(--bg);box-shadow:0 0 0 3px var(--accent)}
.timeline-year{font-size:.82rem;font-weight:700;color:var(--accent);letter-spacing:1px;text-transform:uppercase;margin-bottom:6px}
.timeline-title{font-size:1.15rem;font-family:'Playfair Display',serif;color:var(--text);margin-bottom:8px}
.timeline-desc{font-size:.9rem;color:var(--text-light);line-height:1.7}

/* === PHOTO GALLERY &mdash; Enhanced Hover === */
.gallery-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:50px}
.gallery-item{border-radius:12px;overflow:hidden;aspect-ratio:1;position:relative;cursor:pointer}
.gallery-item img{width:100%;height:100%;object-fit:cover;transition:transform .6s ease}
.gallery-item:hover img{transform:scale(1.12)}
.gallery-item::after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,transparent 40%,rgba(0,0,0,.5) 100%);opacity:0;transition:opacity .4s}
.gallery-item:hover::after{opacity:1}

/* === BOOKS MEDIA &mdash; Enhanced Cards === */
.media-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:30px;margin-top:50px}
.media-card{background:var(--glass-card);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border-radius:16px;padding:36px;box-shadow:0 4px 20px var(--card-shadow);border:1px solid var(--glass-card-border);transition:all .4s;text-align:center;position:relative;overflow:hidden}
.media-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:var(--gradient-accent);transform:scaleX(0);transform-origin:left;transition:transform .4s ease}
.media-card:hover::before{transform:scaleX(1)}
.media-card:hover{transform:translateY(-8px);box-shadow:0 20px 50px var(--card-shadow)}
.media-card-icon{width:64px;height:64px;margin:0 auto 20px;border-radius:50%;background:var(--bg-alt);display:flex;align-items:center;justify-content:center;color:var(--accent)}
.media-card h3{font-size:1.2rem;margin-bottom:12px;color:var(--text)}
.media-card p{font-size:.9rem;color:var(--text-light);margin-bottom:16px;line-height:1.7}
.media-card a{color:var(--accent);font-weight:600;font-size:.88rem}
.media-card a:hover{color:var(--accent-dark)}

/* === JUDICIAL PHILOSOPHY === */
.philosophy-content{display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center}
.philosophy-text h2{margin-bottom:24px}
.philosophy-text p{color:var(--text-light);margin-bottom:18px;line-height:1.8}
.philosophy-image{border-radius:16px;overflow:hidden}
.philosophy-image img{width:100%;border-radius:16px}

/* === CTA &mdash; Background Image === */
.cta-section{background:var(--gradient-hero);position:relative;overflow:hidden}
.cta-overlay{position:absolute;inset:0;background:url('https://judgemichaelwarren.com/wp-content/uploads/2022/01/IMG_9387.jpg') center/cover;opacity:.15}
.cta-grid{display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:start;position:relative;z-index:2}
.cta-text{color:var(--text-on-dark)}
.cta-text h2{font-size:clamp(2rem,3vw,2.8rem);color:#fff;margin-bottom:20px}
.cta-text p{color:rgba(255,255,255,.75);margin-bottom:30px;font-size:1.05rem;line-height:1.8}

/* Social Links &mdash; Circular Fill */
.social-links{display:flex;gap:12px}
.social-link{width:44px;height:44px;border-radius:50%;border:2px solid rgba(255,255,255,.25);display:flex;align-items:center;justify-content:center;transition:all .4s;color:rgba(255,255,255,.6);position:relative;overflow:hidden;z-index:1}
.social-link::before{content:'';position:absolute;inset:0;background:var(--accent);border-radius:50%;transform:scale(0);transition:transform .4s ease;z-index:-1}
.social-link:hover::before{transform:scale(1)}
.social-link:hover{border-color:var(--accent);color:#fff}

.contact-form{background:rgba(255,255,255,.05);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:40px}
.contact-form h3{color:#fff;margin-bottom:24px;font-size:1.3rem}
.form-group{margin-bottom:20px}
.form-group label{display:block;color:rgba(255,255,255,.7);font-size:.85rem;font-weight:500;margin-bottom:8px}
.form-group input,.form-group textarea{width:100%;padding:12px 16px;border-radius:8px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.05);color:#fff;font-family:'Inter',sans-serif;font-size:.92rem;transition:border-color .3s}
.form-group input::placeholder,.form-group textarea::placeholder{color:rgba(255,255,255,.35)}
.form-group input:focus,.form-group textarea:focus{outline:none;border-color:var(--accent)}
.form-group textarea{resize:vertical;min-height:120px}

/* === BUTTONS &mdash; Gold Glow === */
.btn{display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:6px;font-size:.92rem;font-weight:600;font-family:'Inter',sans-serif;cursor:pointer;border:none;transition:all .3s cubic-bezier(.4,0,.2,1);position:relative;overflow:hidden;letter-spacing:.3px}
.btn-primary{background:var(--accent);color:#fff;box-shadow:0 4px 15px rgba(201,168,76,.3)}
.btn-primary:hover{box-shadow:0 8px 30px rgba(201,168,76,.5),0 0 20px rgba(201,168,76,.3);background:var(--accent-light)}
.btn-dark{background:var(--primary);color:#fff}
.btn-dark:hover{background:var(--primary-light);box-shadow:0 8px 25px var(--card-shadow)}
.btn-submit{width:100%;justify-content:center}

/* === FOOTER &mdash; Enhanced === */
.footer{background:var(--bg-dark);color:rgba(255,255,255,.7);padding:80px 0 30px;position:relative;overflow:hidden}
.footer-bg{position:absolute;inset:0;background:url('https://judgemichaelwarren.com/wp-content/uploads/2022/07/democracy-09-scaled.jpeg') center/cover;opacity:.06}
.footer-inner{position:relative;z-index:2}
.footer-heading{font-size:clamp(1.8rem,3vw,2.5rem);color:rgba(255,255,255,.1);font-family:'Playfair Display',serif;text-transform:uppercase;letter-spacing:4px;text-align:center;margin-bottom:50px}
.footer-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:50px;margin-bottom:50px}
.footer-brand img{height:60px;margin-bottom:20px}
.footer-brand p{font-size:.88rem;line-height:1.8;margin-bottom:20px}
.footer-social{display:flex;gap:12px}
.footer-social a{width:40px;height:40px;border-radius:50%;border:1px solid rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;transition:all .4s;color:rgba(255,255,255,.6);position:relative;overflow:hidden;z-index:1}
.footer-social a::before{content:'';position:absolute;inset:0;background:var(--accent);border-radius:50%;transform:scale(0);transition:transform .4s ease;z-index:-1}
.footer-social a:hover::before{transform:scale(1)}
.footer-social a:hover{border-color:var(--accent);color:#fff}
.footer h4{font-family:'Inter',sans-serif;font-size:.85rem;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#fff;margin-bottom:20px}
.footer ul li{margin-bottom:10px}
.footer ul a{font-size:.88rem;color:rgba(255,255,255,.6);transition:color .3s}
.footer ul a:hover{color:var(--accent-light)}
.footer-contact-item{display:flex;gap:10px;font-size:.88rem;margin-bottom:12px;align-items:flex-start}
.footer-contact-icon{color:var(--accent);flex-shrink:0;margin-top:2px}
.footer-bottom{border-top:1px solid rgba(255,255,255,.08);padding-top:30px;display:flex;flex-direction:column;gap:12px;text-align:center}
.footer-copyright{font-size:.78rem;color:rgba(255,255,255,.3)}
.footer-credit{font-size:.75rem;color:rgba(255,255,255,.25)}
.footer-credit a{color:var(--accent);text-decoration:underline}

/* === DONATE BUTTON === */
.btn-donate{background:var(--gradient-accent);color:#fff;font-weight:700;letter-spacing:.5px;box-shadow:0 4px 15px rgba(201,168,76,.4);text-transform:uppercase;font-size:.85rem;animation:donateGlow 2s ease-in-out infinite}
.btn-donate:hover{box-shadow:0 8px 30px rgba(201,168,76,.6),0 0 20px rgba(201,168,76,.4);transform:translateY(-2px)}
@keyframes donateGlow{0%,100%{box-shadow:0 4px 15px rgba(201,168,76,.4)}50%{box-shadow:0 4px 20px rgba(201,168,76,.6),0 0 15px rgba(201,168,76,.3)}}
.nav-donate{padding:10px 24px;border-radius:6px;background:var(--gradient-accent);color:#fff!important;font-weight:700;letter-spacing:.5px;text-transform:uppercase;font-size:.82rem;box-shadow:0 2px 10px rgba(201,168,76,.3)}
.nav-donate:hover{box-shadow:0 4px 20px rgba(201,168,76,.5);transform:translateY(-1px)}
.nav-donate::after{display:none!important}

/* === PAID FOR DISCLAIMER === */
.paid-for-disclaimer{background:#0a0f1a;color:rgba(255,255,255,.7);text-align:center;padding:16px 20px;font-size:12px;font-family:'Inter',sans-serif;letter-spacing:.3px;line-height:1.5}

/* === BACK TO TOP === */
.back-to-top{position:fixed;bottom:30px;right:30px;width:48px;height:48px;border-radius:50%;background:var(--accent);color:#fff;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;opacity:0;visibility:hidden;transform:translateY(20px);transition:all .3s;z-index:9998;box-shadow:0 4px 15px rgba(0,0,0,.2)}
.back-to-top.show{opacity:1;visibility:visible;transform:translateY(0)}
.back-to-top:hover{transform:translateY(-4px);box-shadow:0 8px 25px rgba(0,0,0,.3)}

/* === COOKIE === */
.cookie-banner{position:fixed;bottom:0;left:0;right:0;background:var(--bg-dark);padding:20px 40px;z-index:99999;display:flex;align-items:center;justify-content:space-between;gap:20px;box-shadow:0 -4px 30px rgba(0,0,0,.2);transform:translateY(100%);transition:transform .4s ease;border-top:1px solid rgba(255,255,255,.08)}
.cookie-banner.show{transform:translateY(0)}
.cookie-banner p{color:rgba(255,255,255,.7);font-size:.85rem;flex:1}
.cookie-btns{display:flex;gap:10px}
.cookie-accept,.cookie-decline{padding:10px 24px;border-radius:6px;border:none;cursor:pointer;font-family:'Inter',sans-serif;font-size:.85rem;font-weight:600;transition:all .3s}
.cookie-accept{background:var(--accent);color:#fff}
.cookie-accept:hover{background:var(--accent-light)}
.cookie-decline{background:transparent;color:rgba(255,255,255,.6);border:1px solid rgba(255,255,255,.2)}
.cookie-decline:hover{border-color:rgba(255,255,255,.4);color:#fff}

/* === SCROLL REVEAL === */
.reveal{opacity:0;transform:translateY(40px);transition:all .8s cubic-bezier(.4,0,.2,1)}
.reveal.visible{opacity:1;transform:translateY(0)}
.reveal-delay-1{transition-delay:.1s}.reveal-delay-2{transition-delay:.2s}.reveal-delay-3{transition-delay:.3s}
.reveal-left{opacity:0;transform:translateX(-40px);transition:all .8s cubic-bezier(.4,0,.2,1)}
.reveal-left.visible{opacity:1;transform:translateX(0)}
.reveal-right{opacity:0;transform:translateX(40px);transition:all .8s cubic-bezier(.4,0,.2,1)}
.reveal-right.visible{opacity:1;transform:translateX(0)}

/* === RESPONSIVE === */
@media(max-width:1024px){
  .bio-grid,.philosophy-content,.cta-grid{grid-template-columns:1fr;gap:40px}
  .gallery-grid{grid-template-columns:repeat(2,1fr)}
  .media-grid{grid-template-columns:1fr;max-width:500px;margin-left:auto;margin-right:auto}
  .footer-grid{grid-template-columns:1fr 1fr}
}
@media(max-width:768px){
  .nav-links{display:none}
  .hamburger{display:flex}
  .theme-switcher{position:fixed;bottom:80px;right:20px;z-index:9997;flex-direction:column;background:var(--bg-dark);border:1px solid rgba(255,255,255,.15);box-shadow:0 4px 20px rgba(0,0,0,.3)}
  .section{padding:60px 0}
  .container{padding:0 20px}
  .nav-inner{padding:0 20px}
  .gallery-grid{grid-template-columns:repeat(2,1fr)}
  .timeline{padding-left:30px}
  .timeline-item{padding-left:30px}
  .footer-grid{grid-template-columns:1fr;gap:30px}
  .cookie-banner{flex-direction:column;text-align:center}
  .page-hero-content{padding:140px 20px 60px}
  .section-divider{height:40px}
}
@media(max-width:480px){.gallery-grid{grid-template-columns:1fr 1fr;gap:10px}}
@media print{
  .nav,.back-to-top,.cookie-banner,.scroll-progress,.loader-screen,.theme-switcher,.hero-particles,.cursor-spotlight,.section-divider{display:none!important}
  .page-hero{min-height:auto;background:#fff!important;color:#000!important}
  .page-hero h1{-webkit-text-fill-color:#000!important}
  body{font-size:12pt}
  .section-dark{background:#fff!important;color:#000!important}
  .cta-section{background:#fff!important}
  .cta-text,.cta-text h2,.cta-text p{color:#000!important}
  .footer{background:#fff!important;color:#000!important}
}
</style>
<?php wp_head(); ?>
</head>
<body>
<a href="#main-content" class="skip-link">Skip to main content</a>

<!-- Loading Screen -->
<div class="loader-screen" id="loader">
  <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Logo-For-Judge-Warren.png" alt="Warren for Michigan Supreme Court" class="loader-logo">
  <div class="loader-bar"></div>
</div>

<!-- Scroll Progress -->
<div class="scroll-progress" id="scrollProgress"></div>

<!-- Navigation -->
<nav class="nav" id="navbar" role="navigation" aria-label="Main navigation">
  <div class="nav-inner">
    <a href="<?php echo home_url('/'); ?>" class="nav-logo" aria-label="Warren for Michigan Supreme Court Home">
      <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Logo-For-Judge-Warren.png" alt="Warren for Michigan Supreme Court" id="navLogo">
    </a>
    <div class="nav-links">
      <a href="<?php echo home_url('/'); ?>">Home</a>
      <a href="<?php echo home_url('/about/'); ?>" class="active">About</a>
      <a href="<?php echo home_url('/media-appearances/'); ?>">Media</a>
      <a href="https://secure.anedot.com/michael-warren-for-supreme-court/donate" class="nav-donate" target="_blank" rel="noopener">&#x1F1FA;&#x1F1F8; Donate</a>
    </div>

    <button class="hamburger" id="hamburger" aria-label="Toggle menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>
<div class="mobile-overlay" id="mobileOverlay"></div>
<div class="mobile-menu" id="mobileMenu" role="navigation" aria-label="Mobile navigation">
  <a href="<?php echo home_url('/'); ?>">Home</a>
  <a href="<?php echo home_url('/about/'); ?>">About</a>
  <a href="<?php echo home_url('/media-appearances/'); ?>">Media</a>
  <a href="https://secure.anedot.com/michael-warren-for-supreme-court/donate" style="color:var(--accent);font-weight:700">&#x1F1FA;&#x1F1F8; Donate</a>
</div>

<main id="main-content">

<!-- Page Hero -->
<section class="page-hero" id="heroSection">
  <div class="page-hero-bg" id="heroBg" style="background-image:url('https://judgemichaelwarren.com/wp-content/uploads/2022/07/2S4A9038-scaled.jpeg')"></div>
  <div class="page-hero-overlay"></div>
  <div class="hero-particles" id="heroParticles"></div>
  <div class="cursor-spotlight" id="heroSpotlight" style="opacity:0;"></div>
  <div class="page-hero-content">
    <h1>About Judge Warren</h1>
    <p>Over two decades of distinguished service, 400+ jury trials, and a life dedicated to justice, constitutional principles, and civic education. Now running for Michigan Supreme Court &mdash; Defender of the Constitution.</p>
  </div>
</section>

<!-- Divider -->
<div class="section-divider" style="background:var(--primary-dark)"><div style="position:absolute;bottom:0;left:0;right:0;height:100%;background:var(--bg);clip-path:polygon(0 40%,100% 0,100% 100%,0 100%)"></div></div>

<!-- Full Biography -->
<section class="section section-light" id="biography">
  <div class="container">
    <div class="bio-grid">
      <div class="bio-image reveal-left">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2022/07/2S4A9038-scaled.jpeg" alt="Judge Michael Warren" loading="lazy">
      </div>
      <div class="bio-content reveal-right">
        <p class="section-label">Biography</p>
        <h2 class="section-title">A Legacy of Justice &amp; Service</h2>
        <p>Judge Michael Warren has served on the Oakland County Circuit Court since 2002, establishing himself as one of Michigan's most accomplished and respected jurists. Over his tenure, he has presided over more than 400 jury trials and over 1,000 days of trial proceedings &mdash; more trial experience than the entire current Michigan Supreme Court combined. He interprets the law as written and does not legislate from the bench.</p>
        <p>A graduate of the University of Michigan Law School (cum laude) and Wayne State University (Honors History), Judge Warren brings a rare combination of legal rigor and historical depth to the bench. His academic excellence laid the foundation for a career defined by constitutional fidelity and judicial integrity.</p>
        <p>Beyond the courtroom, Judge Warren serves as a Business Law Professor at Wayne State University and he has taught Constitutional Law at Western Michigan University Cooley Law School, where he inspires the next generation of business and legal professionals with his passion for American founding principles.</p>
        <p>His contributions to civic life have been recognized at the highest levels: Judge of the Decade by the International Association of Top Professionals (IAOTP), Distinguished Public Servant Award from the Oakland County Bar Association, and induction into the IAOTP Hall of Fame.</p>
        <p>As a former member of the Michigan State Board of Education, Judge Warren has championed civic literacy and the teaching of American history and constitutional principles in schools across the state.</p>
      </div>
    </div>
  </div>
</section>

<!-- Divider -->
<div class="section-divider" style="background:var(--bg)"><div style="position:absolute;bottom:0;left:0;right:0;height:100%;background:var(--bg-alt);clip-path:polygon(0 0,100% 60%,100% 100%,0 100%)"></div></div>

<!-- Career Timeline -->
<section class="section section-alt" id="timeline">
  <div class="container">
    <div class="reveal" style="text-align:center;margin-bottom:20px">
      <p class="section-label" style="justify-content:center;display:inline-flex">Career Timeline</p>
      <h2 class="section-title" style="display:block">A Journey of Distinguished Service</h2>
    </div>
    <div class="timeline">
      <div class="timeline-item reveal">
        <div class="timeline-year">1989</div>
        <div class="timeline-title">Wayne State University &mdash; Honors History Degree</div>
        <div class="timeline-desc">Graduated with honors from Wayne State University with a degree in History, developing the deep understanding of American founding principles that would define his career.</div>
      </div>
      <div class="timeline-item reveal">
        <div class="timeline-year">1992</div>
        <div class="timeline-title">University of Michigan Law School, Cum Laude</div>
        <div class="timeline-desc">Earned his Juris Doctor cum laude from the University of Michigan Law School, one of the nation's most prestigious legal institutions.</div>
      </div>
      <div class="timeline-item reveal">
        <div class="timeline-year">1999</div>
        <div class="timeline-title">Member, Michigan State Board of Education</div>
        <div class="timeline-desc">Served on the Michigan State Board of Education, advocating for civic education and the teaching of American history and constitutional principles.</div>
      </div>
      <div class="timeline-item reveal">
        <div class="timeline-year">2002</div>
        <div class="timeline-title">Oakland County Circuit Court Judge</div>
        <div class="timeline-desc">Began his tenure as an Oakland County Circuit Court Judge, a position he would hold with distinction for over two decades.</div>
      </div>
      <div class="timeline-item reveal">
        <div class="timeline-year">2007</div>
        <div class="timeline-title">Published "America's Survival Guide"</div>
        <div class="timeline-desc">Authored a comprehensive guide to the First Principles of American liberty, reaching thousands of readers with a message of constitutional renewal.</div>
      </div>
      <div class="timeline-item reveal">
        <div class="timeline-year">2007</div>
        <div class="timeline-title">Professor &mdash; Constitutional Law &amp; Business Law</div>
        <div class="timeline-desc">Became a Business Law Professor at Wayne State University and has taught Constitutional Law at Western Michigan University Cooley Law School, educating the next generation of business and legal professionals.</div>
      </div>
      <div class="timeline-item reveal">
        <div class="timeline-year">2008</div>
        <div class="timeline-title">Judge of the Decade &amp; Hall of Fame</div>
        <div class="timeline-desc">Recognized as Judge of the Decade by the International Association of Top Professionals and inducted into the IAOTP Hall of Fame.</div>
      </div>
      <div class="timeline-item reveal">
        <div class="timeline-year">2009</div>
        <div class="timeline-title">Co-Founded Patriot Week</div>
        <div class="timeline-desc">Co-founded Patriot Week with his daughter Leah, creating a national celebration to renew America's commitment to its First Principles and civic virtues.</div>
      </div>
      <div class="timeline-item reveal">
        <div class="timeline-year">2012</div>
        <div class="timeline-title">Patriot Lessons Podcast &amp; TV Show</div>
        <div class="timeline-desc">Launched the Patriot Lessons podcast and TV show, exploring constitutional principles, American history, and civic education for a national audience.</div>
      </div>
      <div class="timeline-item reveal">
        <div class="timeline-year">Recognition</div>
        <div class="timeline-title">Distinguished Public Servant Award</div>
        <div class="timeline-desc">Received the Distinguished Public Servant Award from the Oakland County Bar Association for his extraordinary contributions to justice and civic life.</div>
      </div>
      <div class="timeline-item reveal">
        <div class="timeline-year">2026</div>
        <div class="timeline-title">Published "The Revolutionary Words that Forged America"</div>
        <div class="timeline-desc">Authored "The Revolutionary Words that Forged America &mdash; The Definitive Guide to the Declaration of Independence" (Republic Books, 2026), a line-by-line analysis of America's charter marking the 250th anniversary of the Declaration.</div>
      </div>
    </div>
  </div>
</section>

<!-- Divider -->
<div class="section-divider" style="background:var(--bg-alt)"><div style="position:absolute;bottom:0;left:0;right:0;height:100%;background:var(--bg);clip-path:polygon(0 40%,100% 0,100% 100%,0 100%)"></div></div>

<!-- Photo Gallery -->
<section class="section section-light" id="gallery">
  <div class="container">
    <div class="reveal" style="text-align:center;margin-bottom:20px">
      <p class="section-label" style="justify-content:center;display:inline-flex">Gallery</p>
      <h2 class="section-title" style="display:block">In Service &amp; In Action</h2>
    </div>
    <div class="gallery-grid">
      <div class="gallery-item reveal reveal-delay-1"><img src="https://judgemichaelwarren.com/wp-content/uploads/2022/01/IMG_4115.jpg" alt="Judge Warren" loading="lazy"></div>
      <div class="gallery-item reveal reveal-delay-2"><img src="https://judgemichaelwarren.com/wp-content/uploads/2022/01/IMG_7270-scaled.jpg" alt="Judge Warren speaking" loading="lazy"></div>
      <div class="gallery-item reveal reveal-delay-3"><img src="https://judgemichaelwarren.com/wp-content/uploads/2022/01/IMG_9303-scaled.jpg" alt="Judge Warren event" loading="lazy"></div>
      <div class="gallery-item reveal"><img src="https://judgemichaelwarren.com/wp-content/uploads/2022/01/IMG_9387.jpg" alt="Judge Warren" loading="lazy"></div>
      <div class="gallery-item reveal reveal-delay-1"><img src="https://judgemichaelwarren.com/wp-content/uploads/2022/02/democracy-03-scaled-e1643983585155.jpg" alt="Judge Warren at event" loading="lazy"></div>
      <div class="gallery-item reveal reveal-delay-2"><img src="https://judgemichaelwarren.com/wp-content/uploads/2022/07/democracy-09-scaled.jpeg" alt="Judge Warren speaking" loading="lazy"></div>
      <div class="gallery-item reveal reveal-delay-3"><img src="https://judgemichaelwarren.com/wp-content/uploads/2022/07/IMG_0507.jpg" alt="Judge Warren" loading="lazy"></div>
      <div class="gallery-item reveal"><img src="https://judgemichaelwarren.com/wp-content/uploads/2022/07/IMG_0986.jpg" alt="Judge Warren with group" loading="lazy"></div>
    </div>
  </div>
</section>

<!-- Divider -->
<div class="section-divider" style="background:var(--bg)"><div style="position:absolute;bottom:0;left:0;right:0;height:100%;background:var(--bg-alt);clip-path:polygon(0 0,100% 60%,100% 100%,0 100%)"></div></div>

<!-- Books & Media -->
<section class="section section-alt" id="media">
  <div class="container">
    <div class="reveal" style="text-align:center;margin-bottom:20px">
      <p class="section-label" style="justify-content:center;display:inline-flex">Books &amp; Media</p>
      <h2 class="section-title" style="display:block">Educating America</h2>
      <p class="section-subtitle" style="margin:0 auto">Judge Warren's work extends far beyond the courtroom &mdash; through books, media, and national events, he champions civic renewal and constitutional literacy.</p>
    </div>
    <div class="media-grid">
      <div class="media-card reveal reveal-delay-1" data-tilt>
        <div class="media-card-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
        </div>
        <h3>America's Survival Guide</h3>
        <p>A comprehensive exploration of the First Principles that sustain American democracy &mdash; the values, ideas, and institutions that have made America exceptional.</p>
        <a href="https://www.amazon.com/Americas-Survival-Guide-Michael-Warren/dp/1934248312" target="_blank" rel="noopener">View on Amazon &rarr;</a>
      </div>
      <div class="media-card reveal reveal-delay-2" data-tilt>
        <div class="media-card-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
        </div>
        <h3>Patriot Week</h3>
        <p>Co-founded with his daughter Leah, this national celebration renews America's commitment to its First Principles &mdash; from the First Amendment to the courage of the founders.</p>
        <a href="https://www.PatriotWeek.org" target="_blank" rel="noopener">Visit Site &rarr;</a>
      </div>
      <div class="media-card reveal reveal-delay-3" data-tilt>
        <div class="media-card-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>
        </div>
        <h3>Patriot Lessons</h3>
        <p>Judge Warren's podcast and TV show exploring constitutional principles, American history, and civic education &mdash; featured on ABC, CBS, FOX, NBC, and CW.</p>
        <a href="<?php echo home_url('/media-appearances/'); ?>">Watch &amp; Listen &rarr;</a>
      </div>
      <div class="media-card reveal" data-tilt>
        <div class="media-card-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
        </div>
        <h3>The Revolutionary Words that Forged America</h3>
        <p>The definitive guide to the Declaration of Independence &mdash; a line-by-line analysis of America's charter, its drafting, historical circumstances, underlying philosophy, and legal force. (Republic Books, 2026)</p>
        <a href="https://www.amazon.com/Revolutionary-Words-that-Forged-America/dp/1645721205" target="_blank" rel="noopener">View on Amazon &rarr;</a>
      </div>
    </div>
  </div>
</section>

<!-- Divider -->
<div class="section-divider" style="background:var(--bg-alt)"><div style="position:absolute;bottom:0;left:0;right:0;height:100%;background:var(--bg);clip-path:polygon(0 40%,100% 0,100% 100%,0 100%)"></div></div>

<!-- Judicial Philosophy -->
<section class="section section-light" id="philosophy">
  <div class="container">
    <div class="philosophy-content">
      <div class="philosophy-text reveal-left">
        <p class="section-label">Judicial Philosophy</p>
        <h2 class="section-title">Faithful to the Constitution as Written</h2>
        <p>Judge Warren's judicial philosophy is rooted in textualism and originalism &mdash; he believes the Constitution should be interpreted according to its original meaning and the intent of its framers. He interprets the law as written and does not legislate from the bench.</p>
        <p>He rejects judicial activism in all its forms, maintaining that judges must apply the law as written rather than legislating from the bench. This is the philosophy he will bring to the Michigan Supreme Court &mdash; ensuring that the democratic process and the separation of powers remain intact.</p>
        <p>His approach to the law is informed by a deep understanding of American history and the principles that animated the founding generation. For Judge Warren, the Constitution is not a "living document" to be reinterpreted at will &mdash; it is the supreme law of the land, a bulwark against tyranny, and a guarantee of individual liberty.</p>
        <p>On the bench, this philosophy translates into equal justice for all &mdash; regardless of status, race, gender, or wealth. Every litigant receives the same fair hearing, every case is decided on the merits, and every ruling is grounded in the text of the law.</p>
        <a href="https://judgemichaelwarren.com/wp-content/uploads/2022/03/Judicial-Philosphy-Warren-COA.pdf" target="_blank" rel="noopener" class="btn btn-dark" style="margin-top:24px">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><polyline points="9 15 12 18 15 15"/></svg>
          Read Judicial Philosophy PDF
        </a>
      </div>
      <div class="philosophy-image reveal-right">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2022/03/0-1.jpg" alt="Judge Warren" loading="lazy">
      </div>
    </div>
  </div>
</section>

<!-- Get Involved CTA -->
<section class="section cta-section" id="contact">
  <div class="cta-overlay"></div>
  <div class="cursor-spotlight" id="ctaSpotlight" style="opacity:0;"></div>
  <div class="container">
    <div class="cta-grid">
      <div class="cta-text reveal-left">
        <p class="section-label" style="color:var(--accent-light);border-left-color:var(--accent-light)">Get Involved</p>
        <h2>We Win With Warren!</h2>
        <p>On November 3rd, 2026 &mdash; Vote Michael Warren for Michigan Supreme Court. Whether you want to learn more, donate, invite him to speak, or simply connect &mdash; reach out. Every voice matters in the fight to preserve our constitutional republic.</p>
        <a href="https://secure.anedot.com/michael-warren-for-supreme-court/donate" class="btn btn-donate" target="_blank" rel="noopener" style="margin-bottom:20px">&#x1F1FA;&#x1F1F8; Donate to the Campaign</a>
        <div class="social-links">
          <a href="https://www.facebook.com/WarrenforMI" target="_blank" rel="noopener" class="social-link" aria-label="Facebook"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
          <a href="https://www.instagram.com/judgewarrenforMI" target="_blank" rel="noopener" class="social-link" aria-label="Instagram"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a>
          <a href="https://www.youtube.com/@judgemichaelwarren" target="_blank" rel="noopener" class="social-link" aria-label="YouTube"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19.13C5.12 19.56 12 19.56 12 19.56s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.43z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"/></svg></a>
          <a href="https://x.com/warrenformi" target="_blank" rel="noopener" class="social-link" aria-label="X/Twitter"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg></a>
          <a href="https://www.linkedin.com/in/judge-michael-warren/" target="_blank" rel="noopener" class="social-link" aria-label="LinkedIn"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a>
        </div>
      </div>
      <div class="contact-form reveal-right">
        <h3>Send a Message</h3>
        <form onsubmit="event.preventDefault();this.querySelector('.btn-submit').textContent='Message Sent!';this.reset();">
          <div class="form-group">
            <label for="name">Your Name</label>
            <input type="text" id="name" placeholder="John Smith" required>
          </div>
          <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" placeholder="john@example.com" required>
          </div>
          <div class="form-group">
            <label for="message">Message</label>
            <textarea id="message" placeholder="How can we help?" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-submit">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
            Send Message
          </button>
        </form>
      </div>
    </div>
  </div>
</section>

</main>

<!-- Footer -->
<footer class="footer" role="contentinfo">
  <div class="footer-bg"></div>
  <div class="footer-inner">
  <div class="container">
    <div class="footer-heading">Warren for Michigan Supreme Court</div>
    <div class="footer-grid">
      <div class="footer-brand">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Logo-For-Judge-Warren.png" alt="Warren for Michigan Supreme Court" loading="lazy">
        <p>Judge Michael Warren &mdash; Candidate for Michigan Supreme Court. Defender of the Constitution with 400+ jury trials, constitutional law professor, author, Patriot Week co-founder. We Win With Warren!</p>
        <div class="footer-social">
          <a href="https://www.facebook.com/WarrenforMI" target="_blank" rel="noopener" aria-label="Facebook"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
          <a href="https://www.instagram.com/judgewarrenforMI" target="_blank" rel="noopener" aria-label="Instagram"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a>
          <a href="https://www.youtube.com/@judgemichaelwarren" target="_blank" rel="noopener" aria-label="YouTube"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19.13C5.12 19.56 12 19.56 12 19.56s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.43z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"/></svg></a>
          <a href="https://x.com/warrenformi" target="_blank" rel="noopener" aria-label="X/Twitter"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg></a>
          <a href="https://www.linkedin.com/in/judge-michael-warren/" target="_blank" rel="noopener" aria-label="LinkedIn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a>
        </div>
      </div>
      <div>
        <h4>Quick Links</h4>
        <ul>
          <li><a href="<?php echo home_url('/'); ?>">Home</a></li>
          <li><a href="<?php echo home_url('/about/'); ?>">About</a></li>
          <li><a href="<?php echo home_url('/media-appearances/'); ?>">Media</a></li>
        </ul>
      </div>
      <div>
        <h4>Resources</h4>
        <ul>
          <li><a href="https://www.amazon.com/Americas-Survival-Guide-Michael-Warren/dp/1934248312" target="_blank" rel="noopener">America's Survival Guide</a></li>
          <li><a href="https://www.PatriotWeek.org" target="_blank" rel="noopener">Patriot Week</a></li>
          <li><a href="<?php echo home_url('/media-appearances/'); ?>">Patriot Lessons</a></li>
        </ul>
      </div>
      <div>
        <h4>Contact</h4>
        <div class="footer-contact-item">
          <span class="footer-contact-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg></span>
          <a href="mailto:info@judgemichaelwarren.com">info@judgemichaelwarren.com</a>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <p class="footer-copyright">&copy; 2026 Judge Michael Warren. All rights reserved.</p>
      <p class="footer-credit">Built by <a href="https://kirkautomations.com" target="_blank" rel="noopener">Kirk Automations</a></p>
    </div>
  </div>
  </div>
</footer>

<!-- Back to Top -->
<button class="back-to-top" id="backToTop" aria-label="Back to top">
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg>
</button>

<!-- Cookie Consent -->
<div class="cookie-banner" id="cookieBanner" role="dialog" aria-label="Cookie consent">
  <p>We use cookies to enhance your browsing experience and analyze site traffic. By continuing, you agree to our use of cookies.</p>
  <div class="cookie-btns">
    <button class="cookie-accept" id="cookieAccept">Accept</button>
    <button class="cookie-decline" id="cookieDecline">Decline</button>
  </div>
</div>

<script>
(function(){
  'use strict';
  var loader=document.getElementById('loader');
  if(loader){if(sessionStorage.getItem('warren-loaded')){loader.classList.add('hidden')}else{setTimeout(function(){loader.classList.add('hidden');sessionStorage.setItem('warren-loaded','1')},1800)}}



  var nav=document.getElementById('navbar');
  window.addEventListener('scroll',function(){
    var scrollY=window.scrollY;
    if(nav)nav.classList.toggle('scrolled',scrollY>80);
    var progress=document.getElementById('scrollProgress');
    if(progress){var docH=document.documentElement.scrollHeight-window.innerHeight;progress.style.width=docH>0?(scrollY/docH*100)+'%':'0%'}
    var btt=document.getElementById('backToTop');
    if(btt)btt.classList.toggle('show',scrollY>500);
  },{passive:true});

  var btt=document.getElementById('backToTop');
  if(btt)btt.addEventListener('click',function(){window.scrollTo({top:0,behavior:'smooth'})});

  var hamburger=document.getElementById('hamburger'),mobileMenu=document.getElementById('mobileMenu'),mobileOverlay=document.getElementById('mobileOverlay');
  if(hamburger&&mobileMenu&&mobileOverlay){
    var toggleMenu=function(){var open=mobileMenu.classList.toggle('open');hamburger.classList.toggle('active');mobileOverlay.classList.toggle('show');hamburger.setAttribute('aria-expanded',open);document.body.style.overflow=open?'hidden':''};
    hamburger.addEventListener('click',toggleMenu);mobileOverlay.addEventListener('click',toggleMenu);
    mobileMenu.querySelectorAll('a').forEach(function(a){a.addEventListener('click',function(){if(mobileMenu.classList.contains('open'))toggleMenu()})});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&mobileMenu.classList.contains('open'))toggleMenu()});
  }

  var cookieBanner=document.getElementById('cookieBanner');
  if(cookieBanner&&!localStorage.getItem('warren-cookies')){setTimeout(function(){cookieBanner.classList.add('show')},2500)}
  var ca=document.getElementById('cookieAccept');if(ca)ca.addEventListener('click',function(){localStorage.setItem('warren-cookies','accepted');cookieBanner.classList.remove('show')});
  var cd=document.getElementById('cookieDecline');if(cd)cd.addEventListener('click',function(){localStorage.setItem('warren-cookies','declined');cookieBanner.classList.remove('show')});

  var reveals=document.querySelectorAll('.reveal,.reveal-left,.reveal-right');
  if('IntersectionObserver' in window){
    var observer=new IntersectionObserver(function(entries){entries.forEach(function(entry){if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target)}})},{threshold:0.1,rootMargin:'0px 0px -50px 0px'});
    reveals.forEach(function(el){observer.observe(el)});
  }else{reveals.forEach(function(el){el.classList.add('visible')})}

  document.querySelectorAll('[data-tilt]').forEach(function(card){
    card.addEventListener('mousemove',function(e){var rect=card.getBoundingClientRect();var x=(e.clientX-rect.left)/rect.width-0.5;var y=(e.clientY-rect.top)/rect.height-0.5;card.style.transform='perspective(1000px) rotateY('+x*8+'deg) rotateX('+-y*8+'deg) translateY(-8px)'});
    card.addEventListener('mouseleave',function(){card.style.transform=''});
  });

  document.querySelectorAll('.btn').forEach(function(btn){
    btn.addEventListener('mousemove',function(e){var rect=btn.getBoundingClientRect();var x=e.clientX-rect.left-rect.width/2;var y=e.clientY-rect.top-rect.height/2;btn.style.transform='translate('+x*0.15+'px,'+y*0.15+'px)'});
    btn.addEventListener('mouseleave',function(){btn.style.transform=''});
  });

  function setupSpotlight(sectionId,spotlightId){
    var section=document.getElementById(sectionId);var spot=document.getElementById(spotlightId);if(!section||!spot)return;
    section.addEventListener('mousemove',function(e){var rect=section.getBoundingClientRect();spot.style.left=(e.clientX-rect.left)+'px';spot.style.top=(e.clientY-rect.top)+'px';spot.style.opacity='1'});
    section.addEventListener('mouseleave',function(){spot.style.opacity='0'});
  }
  setupSpotlight('heroSection','heroSpotlight');
  setupSpotlight('contact','ctaSpotlight');

  var heroParticles=document.getElementById('heroParticles'),heroSection=document.getElementById('heroSection');
  if(heroParticles&&heroSection){
    var particleCount=0;
    heroSection.addEventListener('mousemove',function(e){
      if(particleCount>30||window.innerWidth<768)return;
      var rect=heroSection.getBoundingClientRect();var particle=document.createElement('div');particleCount++;var size=Math.random()*5+2;
      particle.style.cssText='position:absolute;left:'+(e.clientX-rect.left)+'px;top:'+(e.clientY-rect.top)+'px;width:'+size+'px;height:'+size+'px;border-radius:50%;background:rgba(var(--particle-color),'+(Math.random()*0.5+0.3)+');pointer-events:none;transition:all 1s ease;z-index:5';
      heroParticles.appendChild(particle);
      requestAnimationFrame(function(){particle.style.transform='translate('+(Math.random()-0.5)*80+'px,'+(Math.random()-0.5)*80+'px)';particle.style.opacity='0'});
      setTimeout(function(){particle.remove();particleCount--},1000);
    });
  }

  var heroBg=document.getElementById('heroBg');
  window.addEventListener('scroll',function(){if(heroBg)heroBg.style.transform='translateY('+window.scrollY*0.3+'px)'},{passive:true});

  document.querySelectorAll('a[href^="#"]').forEach(function(a){a.addEventListener('click',function(e){var target=document.querySelector(a.getAttribute('href'));if(target){e.preventDefault();target.scrollIntoView({behavior:'smooth'})}})});
})();
</script>

<!-- Paid For Disclaimer &mdash; Legal Requirement -->
<div class="paid-for-disclaimer">
  Paid for by Michael Warren for Supreme Court &bull; PO Box 1182 &bull; Brighton, MI 48116
</div>

<?php wp_footer(); ?>
</body>
</html>