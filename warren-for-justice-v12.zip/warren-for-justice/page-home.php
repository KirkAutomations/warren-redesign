<?php
/*
Template Name: Home Page
*/
?>
<!DOCTYPE html>
<html lang="en" data-theme="patriot">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Warren for Michigan Supreme Court | Defender of the Constitution</title>
<meta name="description" content="Judge Michael Warren &mdash; Candidate for Michigan Supreme Court. Defender of the Constitution with 400+ jury trials, more trial experience than the entire current Supreme Court combined. We Win With Warren!">
<meta name="keywords" content="Judge Michael Warren, Michigan Supreme Court, constitutional law, Patriot Week, America's Survival Guide, Michigan judge, judicial philosophy, Warren for Supreme Court">
<meta property="og:title" content="Warren for Michigan Supreme Court | Defender of the Constitution">
<meta property="og:description" content="Candidate for Michigan Supreme Court. 400+ jury trials, constitutional law professor, author, and defender of American principles. We Win With Warren!">
<meta property="og:image" content="https://judgemichaelwarren.com/wp-content/uploads/2022/01/Michael_D._Warren_Jr._Fixed.png">
<meta property="og:url" content="https://judgemichaelwarren.com">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Warren for Michigan Supreme Court | Defender of the Constitution">
<meta name="twitter:description" content="Candidate for Michigan Supreme Court. 400+ jury trials, constitutional law professor, author, and defender of American principles. We Win With Warren!">
<link rel="canonical" href="https://judgemichaelwarren.com">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "Judge Michael Warren",
  "jobTitle": "Candidate for Michigan Supreme Court",
  "description": "Judge Michael Warren - Candidate for Michigan Supreme Court. Defender of the Constitution with 400+ jury trials, more trial experience than the entire current Supreme Court combined.",
  "url": "https://judgemichaelwarren.com",
  "image": "https://judgemichaelwarren.com/wp-content/uploads/2022/01/Michael_D._Warren_Jr._Fixed.png",
  "email": "info@judgemichaelwarren.com",
  "alumniOf": [
    {"@type": "CollegeOrUniversity", "name": "University of Michigan Law School"},
    {"@type": "CollegeOrUniversity", "name": "Wayne State University"}
  ],
  "award": ["Judge of the Decade (IAOTP)", "Distinguished Public Servant Award (OCBA)", "IAOTP Hall of Fame"],
  "sameAs": [
    "https://www.facebook.com/WarrenforMI",
    "https://www.youtube.com/@judgemichaelwarren",
    "https://x.com/warrenformi",
    "https://www.instagram.com/judgewarrenforMI"
  ],
  "knowsAbout": ["Constitutional Law", "American History", "Judicial Philosophy"],
  "memberOf": {"@type": "Organization", "name": "Oakland County Circuit Court"},
  "author": {"@type": "Book", "name": "America's Survival Guide", "url": "https://www.amazon.com/Americas-Survival-Guide-Michael-Warren/dp/1934248312"}
}
</script>
<style>
/* === RESET & BASE === */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;font-size:16px}
body{font-family:'Inter',-apple-system,BlinkMacSystemFont,sans-serif;line-height:1.7;overflow-x:hidden;-webkit-font-smoothing:antialiased}
a{text-decoration:none;color:inherit;transition:color .3s}
img{max-width:100%;height:auto;display:block}
ul,ol{list-style:none}
h1,h2,h3,h4,h5,h6{font-family:'Playfair Display',Georgia,serif;line-height:1.2;font-weight:700}
.skip-link{position:absolute;top:-100%;left:50%;transform:translateX(-50%);background:var(--accent);color:#fff;padding:12px 24px;z-index:100000;border-radius:0 0 8px 8px;font-weight:600}
.skip-link:focus{top:0}

/* === THEME: PATRIOT (Default) &mdash; Navy + Gold === */
[data-theme="patriot"]{
  --primary:#1a2744;--primary-dark:#0f1a30;--primary-light:#2a3d60;
  --accent:#c9a84c;--accent-light:#dbc070;--accent-dark:#a88a35;
  --bg:#ffffff;--bg-alt:#f5f5f7;--bg-dark:#0f1a30;
  --text:#1a1a2e;--text-light:#555;--text-on-dark:#ffffff;--text-muted:#888;
  --card-bg:#ffffff;--card-shadow:rgba(26,39,68,0.08);
  --nav-bg:rgba(26,39,68,0.95);--nav-scrolled:rgba(15,26,48,0.97);
  --border:rgba(26,39,68,0.1);
  --gradient-hero:linear-gradient(135deg,#0f1a30 0%,#1a2744 50%,#2a3d60 100%);
  --gradient-accent:linear-gradient(135deg,#c9a84c,#dbc070);
  --shimmer-color:#c9a84c;--particle-color:201,168,76;
  --glass-card:rgba(255,255,255,0.7);--glass-card-border:rgba(255,255,255,0.3);
}

/* === THEME: CONSTITUTION &mdash; Charcoal + Parchment + Crimson === */
[data-theme="constitution"]{
  --primary:#1c1c2e;--primary-dark:#111120;--primary-light:#2d2d4a;
  --accent:#8b2332;--accent-light:#a83545;--accent-dark:#6e1a27;
  --bg:#f4f0e8;--bg-alt:#ebe5d8;--bg-dark:#111120;
  --text:#1c1c2e;--text-light:#555;--text-on-dark:#e8e0d0;--text-muted:#888;
  --card-bg:#faf6ee;--card-shadow:rgba(28,28,46,0.08);
  --nav-bg:rgba(28,28,46,0.95);--nav-scrolled:rgba(17,17,32,0.97);
  --border:rgba(28,28,46,0.1);
  --gradient-hero:linear-gradient(135deg,#111120 0%,#1c1c2e 50%,#2d2d4a 100%);
  --gradient-accent:linear-gradient(135deg,#8b2332,#a83545);
  --shimmer-color:#d4c5a0;--particle-color:212,197,160;
  --glass-card:rgba(250,246,238,0.7);--glass-card-border:rgba(250,246,238,0.3);
}

/* === THEME: LIBERTY &mdash; Clean White + Navy + Gold === */
[data-theme="liberty"]{
  --primary:#1a2744;--primary-dark:#0f1a30;--primary-light:#2a3d60;
  --accent:#c9a84c;--accent-light:#dbc070;--accent-dark:#a88a35;
  --bg:#faf8f3;--bg-alt:#f0ede4;--bg-dark:#1a2744;
  --text:#1a2744;--text-light:#4a5568;--text-on-dark:#faf8f3;--text-muted:#718096;
  --card-bg:#ffffff;--card-shadow:rgba(26,39,68,0.06);
  --nav-bg:rgba(250,248,243,0.95);--nav-scrolled:rgba(250,248,243,0.98);
  --border:rgba(26,39,68,0.08);
  --gradient-hero:linear-gradient(135deg,#1a2744 0%,#2a3d60 50%,#3a5080 100%);
  --gradient-accent:linear-gradient(135deg,#c9a84c,#dbc070);
  --shimmer-color:#c9a84c;--particle-color:201,168,76;
  --glass-card:rgba(255,255,255,0.7);--glass-card-border:rgba(255,255,255,0.3);
}

/* === LOADING SCREEN === */
.loader-screen{position:fixed;top:0;left:0;width:100%;height:100%;background:var(--bg-dark);display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:999999;transition:opacity .6s ease,visibility .6s ease}
.loader-screen.hidden{opacity:0;visibility:hidden;pointer-events:none}
.loader-logo{width:280px;opacity:0;animation:loaderFade 1.5s ease forwards}
@keyframes loaderFade{0%{opacity:0;transform:scale(.9)}50%{opacity:1;transform:scale(1.02)}100%{opacity:1;transform:scale(1)}}
.loader-bar{position:absolute;bottom:40%;left:50%;transform:translateX(-50%);width:200px;height:2px;background:rgba(255,255,255,.1);border-radius:2px;overflow:hidden}
.loader-bar::after{content:'';position:absolute;left:0;top:0;height:100%;width:0;background:var(--gradient-accent);animation:loaderProgress 1.5s ease forwards}
@keyframes loaderProgress{to{width:100%}}

/* === SCROLL PROGRESS === */
.scroll-progress{position:fixed;top:0;left:0;height:3px;background:var(--gradient-accent);width:0%;z-index:100001;transition:width .1s linear}

/* === NAVIGATION === */
.nav{position:fixed;top:0;left:0;right:0;z-index:10000;padding:18px 0;background:transparent;transition:all .4s cubic-bezier(.4,0,.2,1)}
.nav.scrolled{padding:10px 0;background:var(--nav-scrolled);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);box-shadow:0 2px 30px rgba(0,0,0,.15)}
[data-theme="liberty"] .nav{background:transparent}
[data-theme="liberty"] .nav.scrolled{background:var(--nav-scrolled);box-shadow:0 1px 20px rgba(0,0,0,.06)}
.nav-inner{max-width:1400px;margin:0 auto;padding:0 40px;display:flex;align-items:center;justify-content:space-between}
.nav-logo img{height:72px;transition:height .3s;filter:drop-shadow(0 2px 8px rgba(0,0,0,.25));background:rgba(255,255,255,1);padding:10px 16px;border-radius:10px;border:1px solid rgba(0,0,0,.08)}
.nav.scrolled .nav-logo img{height:56px}
.nav-links{display:flex;gap:32px;align-items:center}
.nav-links a{font-size:.88rem;font-weight:500;letter-spacing:.3px;color:var(--text-on-dark);position:relative;padding:4px 0;transition:color .3s,opacity .3s}
[data-theme="liberty"] .nav-links a{color:var(--text)}
[data-theme="liberty"] .nav.scrolled .nav-links a{color:var(--text)}
.nav-links a::after{content:'';position:absolute;bottom:-2px;left:0;width:0;height:2px;background:var(--accent);transition:width .3s ease}
.nav-links a:hover::after,.nav-links a.active::after{width:100%}
.nav-links a:hover{color:var(--accent-light)}

/* Theme Switcher &mdash; Enhanced Glass */
.theme-switcher{display:flex;background:rgba(255,255,255,.12);border-radius:30px;padding:3px;border:1px solid rgba(255,255,255,.2);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);box-shadow:0 4px 15px rgba(0,0,0,.1)}
[data-theme="liberty"] .theme-switcher{background:rgba(0,0,0,.06);border-color:rgba(0,0,0,.12);box-shadow:0 4px 15px rgba(0,0,0,.05)}
.theme-btn{padding:5px 14px;border-radius:25px;border:none;cursor:pointer;font-size:.72rem;font-weight:600;font-family:'Inter',sans-serif;background:transparent;color:rgba(255,255,255,.6);transition:all .3s;letter-spacing:.5px}
[data-theme="liberty"] .theme-btn{color:rgba(0,0,0,.4)}
.theme-btn.active{background:var(--accent);color:#fff;box-shadow:0 2px 10px rgba(0,0,0,.2)}
.theme-btn:hover:not(.active){color:#fff;background:rgba(255,255,255,.15)}
[data-theme="liberty"] .theme-btn:hover:not(.active){color:var(--text);background:rgba(0,0,0,.08)}

/* Hamburger */
.hamburger{display:none;flex-direction:column;gap:5px;cursor:pointer;padding:8px;z-index:10001;background:none;border:none}
.hamburger span{display:block;width:24px;height:2px;background:var(--text-on-dark);transition:all .3s;border-radius:2px}
[data-theme="liberty"] .hamburger span{background:var(--text)}
.hamburger.active span:nth-child(1){transform:rotate(45deg) translate(5px,5px)}
.hamburger.active span:nth-child(2){opacity:0}
.hamburger.active span:nth-child(3){transform:rotate(-45deg) translate(5px,-5px)}

.mobile-menu{position:fixed;top:0;right:-100%;width:320px;height:100vh;background:var(--bg-dark);z-index:10000;padding:100px 40px 40px;transition:right .4s cubic-bezier(.4,0,.2,1);box-shadow:-10px 0 40px rgba(0,0,0,.3)}
.mobile-menu.open{right:0}
.mobile-menu a{display:block;padding:16px 0;font-size:1.1rem;color:var(--text-on-dark);border-bottom:1px solid rgba(255,255,255,.05);font-weight:500}
.mobile-menu a:hover{color:var(--accent)}
.mobile-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;opacity:0;visibility:hidden;transition:all .3s}
.mobile-overlay.show{opacity:1;visibility:visible}

/* === HERO === */
.hero{position:relative;min-height:100vh;display:flex;align-items:center;background:var(--gradient-hero);overflow:hidden}
.hero-bg-image{position:absolute;inset:0;background:url('https://judgemichaelwarren.com/wp-content/uploads/2022/02/democracy-03-scaled-e1643983585155.jpg') center/cover;opacity:.18;transition:transform .1s linear}
.hero-overlay{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.3) 0%,rgba(0,0,0,.1) 50%,rgba(0,0,0,.4) 100%)}
.hero-particles{position:absolute;inset:0;pointer-events:none;overflow:hidden}
.hero-content{position:relative;z-index:10;max-width:1400px;margin:0 auto;padding:0 40px;width:100%;padding-top:120px;padding-bottom:80px;display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center}
.hero-text{max-width:640px}
.hero-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);padding:8px 20px;border-radius:50px;margin-bottom:30px;font-size:.82rem;font-weight:500;color:var(--accent-light);letter-spacing:1.5px;text-transform:uppercase;opacity:0;animation:fadeInUp .8s ease .5s forwards}
.hero-badge-dot{width:8px;height:8px;border-radius:50%;background:var(--accent);animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.5;transform:scale(1.3)}}
.hero h1{font-size:clamp(2.8rem,5.5vw,4.5rem);font-weight:700;color:#fff;margin-bottom:20px;letter-spacing:-0.5px;opacity:0;animation:fadeInUp .8s ease .7s forwards,shimmer 4s ease 2s infinite;background:linear-gradient(90deg,#fff 0%,#fff 40%,var(--shimmer-color) 50%,#fff 60%,#fff 100%);background-size:200% 100%;-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
@keyframes shimmer{0%{background-position:100% 0}100%{background-position:-100% 0}}
.hero-subtitle{font-size:clamp(1.1rem,2vw,1.4rem);color:rgba(255,255,255,.8);margin-bottom:12px;font-weight:300;opacity:0;animation:fadeInUp .8s ease .9s forwards}
.hero-tagline{font-size:clamp(1rem,1.5vw,1.15rem);color:var(--accent-light);font-family:'Playfair Display',serif;font-style:italic;margin-bottom:40px;min-height:1.6em;opacity:0;animation:fadeInUp .8s ease 1.1s forwards}
.typing-cursor{display:inline-block;width:2px;height:1em;background:var(--accent);margin-left:2px;animation:blink 1s infinite;vertical-align:text-bottom}
@keyframes blink{0%,50%{opacity:1}51%,100%{opacity:0}}
.hero-ctas{display:flex;gap:16px;flex-wrap:wrap;opacity:0;animation:fadeInUp .8s ease 1.3s forwards}
@keyframes fadeInUp{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}

/* Hero Portrait &mdash; Animated Gold Glow */
.hero-portrait{text-align:center;opacity:0;animation:fadeInUp .8s ease 1s forwards;position:relative}
.hero-portrait img{width:340px;max-width:100%;border-radius:20px;box-shadow:0 25px 60px rgba(0,0,0,.4);border:3px solid rgba(255,255,255,.1);animation:portraitGlow 3s ease-in-out infinite}
@keyframes portraitGlow{0%,100%{box-shadow:0 25px 60px rgba(0,0,0,.4),0 0 20px rgba(201,168,76,.2),0 0 40px rgba(201,168,76,.1)}50%{box-shadow:0 25px 60px rgba(0,0,0,.4),0 0 30px rgba(201,168,76,.4),0 0 60px rgba(201,168,76,.2)}}

/* Floating Badge */
.hero-floating-badge{position:absolute;bottom:20px;right:-10px;background:var(--gradient-accent);color:#fff;padding:8px 18px;border-radius:30px;font-size:.78rem;font-weight:700;font-family:'Inter',sans-serif;letter-spacing:.5px;box-shadow:0 4px 20px rgba(201,168,76,.4);animation:floatBadge 3s ease-in-out infinite;white-space:nowrap;z-index:5}
@keyframes floatBadge{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}

/* Scale of Justice icon in hero heading */
.hero-justice-icon{display:inline-block;width:0.7em;height:0.7em;vertical-align:middle;margin:0 0.1em;opacity:0.7;filter:drop-shadow(0 0 4px rgba(201,168,76,.4))}

/* === BUTTONS &mdash; Gold Glow on Hover === */
.btn{display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:6px;font-size:.92rem;font-weight:600;font-family:'Inter',sans-serif;cursor:pointer;border:none;transition:all .3s cubic-bezier(.4,0,.2,1);position:relative;overflow:hidden;letter-spacing:.3px}
.btn-primary{background:var(--accent);color:#fff;box-shadow:0 4px 15px rgba(201,168,76,.3)}
.btn-primary:hover{box-shadow:0 8px 30px rgba(201,168,76,.5),0 0 20px rgba(201,168,76,.3);background:var(--accent-light)}
.btn-outline{background:transparent;color:#fff;border:2px solid rgba(255,255,255,.3)}
.btn-outline:hover{border-color:var(--accent);color:var(--accent-light);background:rgba(255,255,255,.05);box-shadow:0 8px 30px rgba(201,168,76,.3),0 0 15px rgba(201,168,76,.2)}
.btn-dark{background:var(--primary);color:#fff}
.btn-dark:hover{background:var(--primary-light);box-shadow:0 8px 25px var(--card-shadow)}

/* === SOCIAL PROOF TICKER &mdash; Enhanced === */
.ticker{background:var(--bg-dark);overflow:hidden;padding:18px 0;position:relative;border-top:2px solid rgba(201,168,76,.2);border-bottom:2px solid rgba(201,168,76,.2)}
.ticker-label{position:absolute;left:0;top:0;bottom:0;display:flex;align-items:center;padding:0 24px;background:var(--accent);color:#fff;font-size:.72rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;z-index:2;white-space:nowrap}
.ticker-track{display:flex;gap:60px;animation:tickerScroll 25s linear infinite;white-space:nowrap;padding-left:160px}
.ticker-item{display:flex;align-items:center;gap:12px;flex-shrink:0}
.ticker-item img{height:40px;filter:brightness(0) invert(1);opacity:.6;transition:opacity .3s}
.ticker-item:hover img{opacity:1}
.ticker-featured-text{color:rgba(255,255,255,.4);font-size:.68rem;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;font-family:'Inter',sans-serif}
.ticker-network-text{color:rgba(255,255,255,.6);font-size:1.1rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;font-family:'Inter',sans-serif}
@keyframes tickerScroll{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}

/* === SECTIONS === */
.section{padding:100px 0;position:relative}
.section-dark{background:var(--bg-dark);color:var(--text-on-dark)}
.section-alt{background:var(--bg-alt)}
.section-light{background:var(--bg)}
.container{max-width:1400px;margin:0 auto;padding:0 40px}

/* Section Label &mdash; Gold Left Border */
.section-label{font-size:.78rem;font-weight:700;letter-spacing:3px;text-transform:uppercase;color:var(--accent);margin-bottom:16px;display:inline-flex;align-items:center;gap:12px;border-left:4px solid var(--accent);padding-left:14px}
.section-label::before{display:none}

/* Section Title &mdash; Gold Underline Bar + Tight Spacing */
.section-title{font-size:clamp(2rem,3.5vw,3rem);margin-bottom:20px;color:var(--text);letter-spacing:-0.5px;position:relative;display:inline-block}
.section-title::after{content:'';display:block;width:60px;height:4px;background:var(--gradient-accent);border-radius:2px;margin-top:12px}
.section-dark .section-title{color:var(--text-on-dark)}
.section-subtitle{font-size:1.1rem;color:var(--text-light);max-width:700px;line-height:1.8}
.section-dark .section-subtitle{color:rgba(255,255,255,.7)}

/* Section Dividers &mdash; Angled */
.section-divider{position:relative;height:60px;margin-top:-1px;overflow:hidden}
.section-divider::before{content:'';position:absolute;bottom:0;left:0;right:0;height:100%;background:var(--bg-alt);clip-path:polygon(0 40%,100% 0,100% 100%,0 100%)}
.section-divider-dark::before{background:var(--bg-dark)}
.section-divider-light::before{background:var(--bg)}
.section-divider-alt::before{background:var(--bg-alt)}

/* === ABOUT PREVIEW === */
.about-grid{display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center}
.about-image-wrap{position:relative;border-radius:16px;overflow:hidden}
.about-image-wrap img{width:100%;border-radius:16px;transition:transform 6s ease}
.about-image-wrap:hover img{transform:scale(1.05)}
.about-image-wrap::after{content:'';position:absolute;inset:0;border-radius:16px;border:2px solid var(--accent);top:20px;left:20px;right:-20px;bottom:-20px;z-index:-1;opacity:.3}
.about-text h2{margin-bottom:24px}
.about-text p{margin-bottom:18px;color:var(--text-light)}

/* === STATS &mdash; Gold Numbers with Glow === */
.stats-bar{display:grid;grid-template-columns:repeat(4,1fr);gap:30px}
.stat-item{text-align:center;padding:40px 20px}
.stat-number{font-size:clamp(2.5rem,4vw,3.5rem);font-weight:700;color:var(--accent);font-family:'Playfair Display',serif;margin-bottom:8px;text-shadow:0 0 20px rgba(201,168,76,.3),0 0 40px rgba(201,168,76,.1)}
.stat-label{font-size:.88rem;color:rgba(255,255,255,.6);letter-spacing:1px;text-transform:uppercase;font-weight:500}

/* === PILLAR CARDS &mdash; Glass Morphism + Shine === */
.pillars-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:30px;margin-top:50px}
.pillar-card{background:var(--glass-card);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border-radius:16px;padding:40px 32px;box-shadow:0 4px 20px var(--card-shadow);border:1px solid var(--glass-card-border);transition:all .4s cubic-bezier(.4,0,.2,1);position:relative;overflow:hidden;transform-style:preserve-3d;perspective:1000px}
.pillar-card::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;background:var(--gradient-accent);transform:scaleX(0);transform-origin:left;transition:transform .4s ease}
.pillar-card:hover::before{transform:scaleX(1)}
/* Card shine effect on hover */
.pillar-card::after{content:'';position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:linear-gradient(135deg,transparent 40%,rgba(255,255,255,.08) 50%,transparent 60%);transform:translateX(-100%) rotate(0deg);transition:transform .8s ease;pointer-events:none}
.pillar-card:hover::after{transform:translateX(50%) rotate(0deg)}
.pillar-card:hover{box-shadow:0 20px 50px var(--card-shadow)}
.pillar-icon{width:64px;height:64px;border-radius:12px;background:var(--bg-alt);display:flex;align-items:center;justify-content:center;margin-bottom:24px;color:var(--accent)}
.pillar-card h3{font-size:1.4rem;margin-bottom:16px;color:var(--text)}
.pillar-card p{color:var(--text-light);font-size:.95rem;line-height:1.7;margin-bottom:12px}
.pillar-card ul{margin-top:8px}
.pillar-card ul li{color:var(--text-light);font-size:.88rem;padding:4px 0;padding-left:20px;position:relative}
.pillar-card ul li::before{content:'';position:absolute;left:0;top:12px;width:6px;height:6px;border-radius:50%;background:var(--accent)}

/* === BOOKS & MEDIA &mdash; Enhanced Hover === */
.books-grid{display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center;margin-top:50px}
.book-card{background:var(--card-bg);border-radius:16px;padding:32px;box-shadow:0 4px 20px var(--card-shadow);border:1px solid var(--border);transition:all .4s cubic-bezier(.4,0,.2,1);position:relative;overflow:hidden}
.book-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:var(--gradient-accent);transform:scaleX(0);transform-origin:left;transition:transform .4s ease}
.book-card:hover::before{transform:scaleX(1)}
.book-card:hover{box-shadow:0 20px 50px var(--card-shadow);transform:translateY(-8px)}
.book-card h3{font-size:1.2rem;margin-bottom:12px;color:var(--text)}
.book-card p{font-size:.92rem;color:var(--text-light);margin-bottom:16px;line-height:1.7}
.book-card a{color:var(--accent);font-weight:600;font-size:.9rem}
.book-card a:hover{color:var(--accent-dark)}
.books-text h2{margin-bottom:24px}
.books-text p{color:var(--text-light);margin-bottom:18px}

/* === CONTACT / CTA &mdash; Background Image === */
.cta-section{background:var(--gradient-hero);position:relative;overflow:hidden}
.cta-overlay{position:absolute;inset:0;background:url('https://judgemichaelwarren.com/wp-content/uploads/2022/01/IMG_4115.jpg') center/cover;opacity:.15}
.cta-grid{display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:start;position:relative;z-index:2}
.cta-text{color:var(--text-on-dark)}
.cta-text h2{font-size:clamp(2rem,3vw,2.8rem);color:#fff;margin-bottom:20px}
.cta-text p{color:rgba(255,255,255,.75);margin-bottom:30px;font-size:1.05rem;line-height:1.8}

/* Social Links &mdash; Circular with Fill Animation */
.social-links{display:flex;gap:12px}
.social-link{width:44px;height:44px;border-radius:50%;border:2px solid rgba(255,255,255,.25);display:flex;align-items:center;justify-content:center;transition:all .4s;color:rgba(255,255,255,.6);position:relative;overflow:hidden;z-index:1}
.social-link::before{content:'';position:absolute;inset:0;background:var(--accent);border-radius:50%;transform:scale(0);transition:transform .4s ease;z-index:-1}
.social-link:hover::before{transform:scale(1)}
.social-link:hover{border-color:var(--accent);color:#fff}

.contact-form{background:rgba(255,255,255,.05);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:40px}
.contact-form h3{color:#fff;margin-bottom:24px;font-size:1.3rem}
.form-group{margin-bottom:20px}
.form-group label{display:block;color:rgba(255,255,255,.7);font-size:.85rem;font-weight:500;margin-bottom:8px}
.form-group input,.form-group textarea{width:100%;padding:12px 16px;border-radius:8px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.05);color:#fff;font-family:'Inter',sans-serif;font-size:.92rem;transition:border-color .3s}
.form-group input::placeholder,.form-group textarea::placeholder{color:rgba(255,255,255,.35)}
.form-group input:focus,.form-group textarea:focus{outline:none;border-color:var(--accent)}
.form-group textarea{resize:vertical;min-height:120px}
.btn-submit{width:100%;justify-content:center}

/* === FOOTER &mdash; Enhanced with Background Image === */
.footer{background:var(--bg-dark);color:rgba(255,255,255,.7);padding:80px 0 30px;position:relative;overflow:hidden}
.footer-bg{position:absolute;inset:0;background:url('https://judgemichaelwarren.com/wp-content/uploads/2022/07/democracy-09-scaled.jpeg') center/cover;opacity:.06}
.footer-inner{position:relative;z-index:2}
.footer-heading{font-size:clamp(1.8rem,3vw,2.5rem);color:rgba(255,255,255,.1);font-family:'Playfair Display',serif;text-transform:uppercase;letter-spacing:4px;text-align:center;margin-bottom:50px}
.footer-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:50px;margin-bottom:50px}
.footer-brand img{height:160px;margin-bottom:20px;background:white;padding:14px 22px;border-radius:10px;display:block;margin-left:auto;margin-right:auto}
.footer-brand p{font-size:.88rem;line-height:1.8;margin-bottom:20px}
.footer-social{display:flex;gap:12px}
.footer-social a{width:40px;height:40px;border-radius:50%;border:1px solid rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;transition:all .4s;color:rgba(255,255,255,.6);position:relative;overflow:hidden;z-index:1}
.footer-social a::before{content:'';position:absolute;inset:0;background:var(--accent);border-radius:50%;transform:scale(0);transition:transform .4s ease;z-index:-1}
.footer-social a:hover::before{transform:scale(1)}
.footer-social a:hover{border-color:var(--accent);color:#fff}
.footer h4{font-family:'Inter',sans-serif;font-size:.85rem;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#fff;margin-bottom:20px}
.footer ul li{margin-bottom:10px}
.footer ul a{font-size:.88rem;color:rgba(255,255,255,.6);transition:color .3s}
.footer ul a:hover{color:var(--accent-light)}
.footer-contact-item{display:flex;gap:10px;font-size:.88rem;margin-bottom:12px;align-items:flex-start}
.footer-contact-icon{color:var(--accent);flex-shrink:0;margin-top:2px}
.footer-bottom{border-top:1px solid rgba(255,255,255,.08);padding-top:30px;display:flex;flex-direction:column;gap:12px;text-align:center}
.footer-copyright{font-size:.78rem;color:rgba(255,255,255,.3)}
.footer-credit{font-size:.75rem;color:rgba(255,255,255,.25)}
.footer-credit a{color:var(--accent);text-decoration:underline}
.footer-credit a:hover{color:var(--accent-light)}

/* === BACK TO TOP === */
.back-to-top{position:fixed;bottom:30px;right:30px;width:48px;height:48px;border-radius:50%;background:var(--accent);color:#fff;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;opacity:0;visibility:hidden;transform:translateY(20px);transition:all .3s;z-index:9998;box-shadow:0 4px 15px rgba(0,0,0,.2)}
.back-to-top.show{opacity:1;visibility:visible;transform:translateY(0)}
.back-to-top:hover{transform:translateY(-4px);box-shadow:0 8px 25px rgba(0,0,0,.3)}

/* === COOKIE CONSENT === */
.cookie-banner{position:fixed;bottom:0;left:0;right:0;background:var(--bg-dark);padding:20px 40px;z-index:99999;display:flex;align-items:center;justify-content:space-between;gap:20px;box-shadow:0 -4px 30px rgba(0,0,0,.2);transform:translateY(100%);transition:transform .4s ease;border-top:1px solid rgba(255,255,255,.08)}
.cookie-banner.show{transform:translateY(0)}
.cookie-banner p{color:rgba(255,255,255,.7);font-size:.85rem;flex:1}
.cookie-btns{display:flex;gap:10px}
.cookie-accept,.cookie-decline{padding:10px 24px;border-radius:6px;border:none;cursor:pointer;font-family:'Inter',sans-serif;font-size:.85rem;font-weight:600;transition:all .3s}
.cookie-accept{background:var(--accent);color:#fff}
.cookie-accept:hover{background:var(--accent-light)}
.cookie-decline{background:transparent;color:rgba(255,255,255,.6);border:1px solid rgba(255,255,255,.2)}
.cookie-decline:hover{border-color:rgba(255,255,255,.4);color:#fff}

/* === SCROLL REVEAL === */
.reveal{opacity:0;transform:translateY(40px);transition:all .8s cubic-bezier(.4,0,.2,1)}
.reveal.visible{opacity:1;transform:translateY(0)}
.reveal-delay-1{transition-delay:.1s}.reveal-delay-2{transition-delay:.2s}.reveal-delay-3{transition-delay:.3s}.reveal-delay-4{transition-delay:.4s}
.reveal-left{opacity:0;transform:translateX(-40px);transition:all .8s cubic-bezier(.4,0,.2,1)}
.reveal-left.visible{opacity:1;transform:translateX(0)}
.reveal-right{opacity:0;transform:translateX(40px);transition:all .8s cubic-bezier(.4,0,.2,1)}
.reveal-right.visible{opacity:1;transform:translateX(0)}

/* === CURSOR SPOTLIGHT === */
.cursor-spotlight{position:absolute;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,rgba(var(--particle-color),.06) 0%,transparent 70%);pointer-events:none;z-index:1;transform:translate(-50%,-50%);transition:opacity .3s}

/* === DONATE BUTTON === */
.btn-donate{background:var(--gradient-accent);color:#fff;font-weight:700;letter-spacing:.5px;box-shadow:0 4px 15px rgba(201,168,76,.4);text-transform:uppercase;font-size:.85rem;animation:donateGlow 2s ease-in-out infinite}
.btn-donate:hover{box-shadow:0 8px 30px rgba(201,168,76,.6),0 0 20px rgba(201,168,76,.4);transform:translateY(-2px)}
@keyframes donateGlow{0%,100%{box-shadow:0 4px 15px rgba(201,168,76,.4)}50%{box-shadow:0 4px 20px rgba(201,168,76,.6),0 0 15px rgba(201,168,76,.3)}}
.nav-donate{padding:10px 24px;border-radius:6px;background:var(--gradient-accent);color:#fff!important;font-weight:700;letter-spacing:.5px;text-transform:uppercase;font-size:.82rem;box-shadow:0 2px 10px rgba(201,168,76,.3)}
.nav-donate:hover{box-shadow:0 4px 20px rgba(201,168,76,.5);transform:translateY(-1px)}
.nav-donate::after{display:none!important}

/* === PAID FOR DISCLAIMER === */
.paid-for-disclaimer{background:#0a0f1a;color:rgba(255,255,255,.7);text-align:center;padding:16px 20px;font-size:12px;font-family:'Inter',sans-serif;letter-spacing:.3px;line-height:1.5}

/* === CAMPAIGN SLOGAN === */
.hero-slogan{font-size:clamp(1.2rem,2.2vw,1.6rem);color:var(--accent);font-family:'Playfair Display',serif;font-weight:700;margin-bottom:16px;opacity:0;animation:fadeInUp .8s ease 1s forwards;letter-spacing:1px}

/* === RESPONSIVE === */
@media(max-width:1024px){
  .pillars-grid{grid-template-columns:1fr;max-width:500px;margin-left:auto;margin-right:auto}
  .about-grid,.books-grid,.cta-grid{grid-template-columns:1fr;gap:40px}
  .stats-bar{grid-template-columns:repeat(2,1fr)}
  .footer-grid{grid-template-columns:1fr 1fr}
  .hero-content{grid-template-columns:1fr;text-align:center}
  .hero-portrait{order:-1}
  .hero-portrait img{margin:0 auto;width:280px}
  .hero-badge{margin:0 auto 30px}
  .hero-ctas{justify-content:center}
  .hero-floating-badge{right:auto;left:50%;transform:translateX(-50%);bottom:10px}
  @keyframes floatBadge{0%,100%{transform:translateX(-50%) translateY(0)}50%{transform:translateX(-50%) translateY(-8px)}}
}
@media(max-width:768px){
  .nav-links{display:none}
  .hamburger{display:flex}
  .theme-switcher{position:fixed;bottom:80px;right:20px;z-index:9997;flex-direction:column;background:var(--bg-dark);border:1px solid rgba(255,255,255,.15);box-shadow:0 4px 20px rgba(0,0,0,.3)}
  .hero-content{padding-top:140px}
  .hero h1{font-size:2.4rem}
  .section{padding:60px 0}
  .container{padding:0 20px}
  .nav-inner{padding:0 20px}
  .stats-bar{grid-template-columns:1fr 1fr;gap:10px}
  .stat-item{padding:20px 10px}
  .footer-grid{grid-template-columns:1fr;gap:30px}
  .cookie-banner{flex-direction:column;text-align:center}
  .hero-portrait img{width:220px}
  .ticker-label{display:none}
  .ticker-track{padding-left:20px}
  .section-divider{height:40px}
}
@media(max-width:480px){
  .hero h1{font-size:2rem}
  .hero-ctas{flex-direction:column;align-items:stretch}
  .btn{justify-content:center}
  .stats-bar{grid-template-columns:1fr 1fr}
}
@media print{
  .nav,.back-to-top,.cookie-banner,.scroll-progress,.loader-screen,.ticker,.theme-switcher,.hero-particles,.cursor-spotlight,.section-divider{display:none!important}
  .hero{min-height:auto;background:#fff!important;color:#000!important}
  .hero h1{-webkit-text-fill-color:#000!important}
  body{font-size:12pt}
  .section-dark{background:#fff!important;color:#000!important}
  .section-dark .section-title,.section-dark .stat-number{color:#000!important}
  .cta-section{background:#fff!important}
  .cta-text,.cta-text h2,.cta-text p{color:#000!important}
  .footer{background:#fff!important;color:#000!important}
}
</style>
<?php wp_head(); ?>
</head>
<body>
<!-- Skip to content -->
<a href="#main-content" class="skip-link">Skip to main content</a>

<!-- Loading Screen -->
<div class="loader-screen" id="loader">
  <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Logo-For-Judge-Warren.png" alt="Warren for Michigan Supreme Court" class="loader-logo">
  <div class="loader-bar"></div>
</div>

<!-- Scroll Progress -->
<div class="scroll-progress" id="scrollProgress"></div>

<!-- Navigation -->
<nav class="nav" id="navbar" role="navigation" aria-label="Main navigation">
  <div class="nav-inner">
    <a href="<?php echo home_url('/'); ?>" class="nav-logo" aria-label="Warren for Michigan Supreme Court Home">
      <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Logo-For-Judge-Warren.png" alt="Warren for Michigan Supreme Court" id="navLogo">
    </a>
    <div class="nav-links">
      <a href="<?php echo home_url('/'); ?>" class="active">Home</a>
      <a href="<?php echo home_url('/about/'); ?>">About</a>
      <a href="<?php echo home_url('/media-appearances/'); ?>">Media</a>
      <a href="https://secure.anedot.com/michael-warren-for-supreme-court/donate" class="nav-donate" target="_blank" rel="noopener">Donate</a>
    </div>

    <button class="hamburger" id="hamburger" aria-label="Toggle menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<!-- Mobile Menu -->
<div class="mobile-overlay" id="mobileOverlay"></div>
<div class="mobile-menu" id="mobileMenu" role="navigation" aria-label="Mobile navigation">
  <a href="<?php echo home_url('/'); ?>">Home</a>
  <a href="<?php echo home_url('/about/'); ?>">About</a>
  <a href="<?php echo home_url('/media-appearances/'); ?>">Media</a>
  <a href="https://secure.anedot.com/michael-warren-for-supreme-court/donate" style="color:var(--accent);font-weight:700">Donate</a>
</div>

<!-- MAIN CONTENT -->
<main id="main-content">

<!-- Hero Section -->
<section class="hero" id="heroSection">
  <div class="hero-bg-image" id="heroBg"></div>
  <div class="hero-overlay"></div>
  <div class="hero-particles" id="heroParticles"></div>
  <div class="cursor-spotlight" id="heroSpotlight" style="opacity:0;"></div>
  <div class="hero-content">
    <div class="hero-text" style="text-align:center;max-width:100%;margin:0 auto">
      <div class="hero-badge" style="margin:0 auto 30px"><span class="hero-badge-dot"></span> Warren for Michigan Supreme Court</div>
      <h1 style="text-align:center">Michael Warren for Supreme Court</h1>
      <p class="hero-slogan">We Win With Warren!</p>
      <p class="hero-subtitle">Judge Michael Warren for Michigan Supreme Court &mdash; 400+ jury trials, more trial experience than the entire current Supreme Court combined. Interprets the law as written &mdash; does not legislate from the bench.</p>
      <p class="hero-tagline"><span id="typingText"></span><span class="typing-cursor"></span></p>
      <div class="hero-ctas" style="justify-content:center">
        <a href="https://secure.anedot.com/michael-warren-for-supreme-court/donate" class="btn btn-donate" target="_blank" rel="noopener">Donate Now</a>
        <a href="<?php echo home_url('/about/'); ?>" class="btn btn-primary">Learn More</a>
        <a href="<?php echo home_url('/media-appearances/'); ?>" class="btn btn-outline">Watch &amp; Listen</a>
      </div>
    </div>
    <div class="hero-portrait">
      <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Logo-For-Judge-Warren.png" alt="Warren for Michigan Supreme Court" width="340" height="auto">
      <div class="hero-floating-badge">&#x2696; 400+ Jury Trials</div>
    </div>
  </div>
</section>



<!-- Angled Divider -->
<div class="section-divider"><div class="section-divider" style="height:100%"><div style="position:absolute;bottom:0;left:0;right:0;height:100%;background:var(--bg);clip-path:polygon(0 40%,100% 0,100% 100%,0 100%)"></div></div></div>

<!-- About Preview -->
<section class="section section-light" id="about">
  <div class="container">
    <div class="about-grid">
      <div class="about-image-wrap reveal-left">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2022/07/2S4A9038-scaled.jpeg" alt="Judge Michael Warren" loading="lazy">
      </div>
      <div class="about-text reveal-right">
        <p class="section-label">About the Judge</p>
        <h2 class="section-title">A Lifetime of Service to Justice</h2>
        <p>Judge Michael Warren has served on the Oakland County Circuit Court for over two decades, presiding over more than 400 jury trials &mdash; more trial experience than the entire current Michigan Supreme Court combined. Recognized as Judge of the Decade by the International Association of Top Professionals.</p>
        <p>A graduate of the University of Michigan Law School (cum laude) and Wayne State University (Honors History), Judge Warren combines deep legal scholarship with an unwavering commitment to constitutional principles and equal justice under the law.</p>
        <p>Beyond the bench, he is a Business Law Professor at Wayne State University and he has taught Constitutional Law at Western Michigan University Cooley Law School, where he inspires the next generation of business and legal professionals with his passion for American founding principles. He is also the author of "America's Survival Guide," and co-founder of Patriot Week &mdash; a national celebration of American First Principles.</p>
        <a href="<?php echo home_url('/about/'); ?>" class="btn btn-dark" style="margin-top:24px">Read Full Biography</a>
      </div>
    </div>
  </div>
</section>

<!-- Photo Gallery -->
<section class="section section-alt" id="gallery">
  <div class="container">
    <div class="reveal" style="text-align:center;margin-bottom:20px">
      <p class="section-label" style="justify-content:center;display:inline-flex">Gallery</p>
      <h2 class="section-title" style="display:block">In Service &amp; In Action</h2>
      <p class="section-subtitle" style="margin:0 auto">Judge Warren serving Michigan &mdash; on the bench, in the community, and championing constitutional principles.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:40px">
      <div style="border-radius:12px;overflow:hidden;aspect-ratio:4/3;position:relative">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2022/01/IMG_9303-scaled.jpg" alt="Judge Warren in service" loading="lazy" style="width:100%;height:100%;object-fit:cover;transition:transform .6s">
      </div>
      <div style="border-radius:12px;overflow:hidden;aspect-ratio:4/3;position:relative">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Judge-Warren-Picture.jpg" alt="Judge Warren with community" loading="lazy" style="width:100%;height:100%;object-fit:cover;transition:transform .6s">
      </div>
      <div style="border-radius:12px;overflow:hidden;aspect-ratio:4/3;position:relative">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2022/07/2S4A9038-scaled.jpeg" alt="Judge Warren at event" loading="lazy" style="width:100%;height:100%;object-fit:cover;transition:transform .6s">
      </div>
    </div>
  </div>
</section>

<!-- Angled Divider to Dark -->
<div class="section-divider" style="background:var(--bg-alt)"><div style="position:absolute;bottom:0;left:0;right:0;height:100%;background:var(--bg-dark);clip-path:polygon(0 0,100% 60%,100% 100%,0 100%)"></div></div>

<!-- Stats Section -->
<section class="section section-dark" id="stats">
  <div class="cursor-spotlight" id="statsSpotlight" style="opacity:0;"></div>
  <div class="container" style="position:relative;z-index:2;">
    <div class="stats-bar">
      <div class="stat-item reveal">
        <div class="stat-number" data-target="20" data-suffix="+">0</div>
        <div class="stat-label">Years on the Bench</div>
      </div>
      <div class="stat-item reveal reveal-delay-1">
        <div class="stat-number" data-target="400" data-suffix="+">0</div>
        <div class="stat-label">Jury Trials</div>
      </div>
      <div class="stat-item reveal reveal-delay-2">
        <div class="stat-number" data-target="1000" data-suffix="+">0</div>
        <div class="stat-label">Days of Trial</div>
      </div>
      <div class="stat-item reveal reveal-delay-3">
        <div class="stat-number" data-target="1" data-prefix="" data-suffix="">0</div>
        <div class="stat-label">Hall of Fame Member</div>
      </div>
    </div>
  </div>
</section>

<!-- Angled Divider to Alt -->
<div class="section-divider" style="background:var(--bg-dark)"><div style="position:absolute;bottom:0;left:0;right:0;height:100%;background:var(--bg-alt);clip-path:polygon(0 40%,100% 0,100% 100%,0 100%)"></div></div>

<!-- Three Pillars -->
<section class="section section-alt" id="pillars">
  <div class="container">
    <div class="reveal" style="text-align:center;margin-bottom:20px">
      <p class="section-label" style="justify-content:center;display:inline-flex">Core Principles</p>
      <h2 class="section-title" style="display:block">Three Pillars of Service</h2>
      <p class="section-subtitle" style="margin:0 auto">Judge Warren's career is defined by experience, constitutional fidelity, and an unwavering commitment to fairness.</p>
    </div>
    <div class="pillars-grid">
      <div class="pillar-card reveal reveal-delay-1" data-tilt>
        <div class="pillar-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v18M3 7l9-4 9 4M3 7l3 6h6L9 7M15 7l3 6h6l-3-6"/></svg>
        </div>
        <h3>Experienced &amp; Accomplished</h3>
        <p>Over two decades of distinguished service on the Oakland County Circuit Court, earning the highest honors in the legal profession.</p>
        <ul>
          <li>Judge of the Decade (IAOTP)</li>
          <li>Distinguished Public Servant Award (OCBA)</li>
          <li>Constitutional Law Professor, WMU Cooley</li>
          <li>Former Member, State Board of Education</li>
          <li>U of M Law School, cum laude</li>
          <li>Wayne State University, Honors History</li>
        </ul>
      </div>
      <div class="pillar-card reveal reveal-delay-2" data-tilt>
        <div class="pillar-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
        </div>
        <h3>Defender of the Constitution</h3>
        <p>A steadfast originalist who interprets the law as written, championing American First Principles both on and off the bench.</p>
        <ul>
          <li>Interprets law as written by the founders</li>
          <li>Co-Founder of Patriot Week with daughter Leah</li>
          <li>Author: "America's Survival Guide"</li>
          <li>Host: Patriot Lessons Podcast &amp; TV Show</li>
          <li>Constitutional Law Professor</li>
        </ul>
      </div>
      <div class="pillar-card reveal reveal-delay-3" data-tilt>
        <div class="pillar-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
        </div>
        <h3>Fair &amp; Just</h3>
        <p>Every decision rooted in a fair reading of the law &mdash; equal justice regardless of status, race, gender, or wealth.</p>
        <ul>
          <li>Decisions based on fair reading of law</li>
          <li>Equal justice regardless of status or background</li>
          <li>Creator of the Reset Program for probationers</li>
          <li>Committed to rehabilitation and redemption</li>
          <li>400+ jury trials presided with integrity</li>
          <li>Interprets the law as written</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- Angled Divider to Light -->
<div class="section-divider" style="background:var(--bg-alt)"><div style="position:absolute;bottom:0;left:0;right:0;height:100%;background:var(--bg);clip-path:polygon(0 0,100% 60%,100% 100%,0 100%)"></div></div>

<!-- Books & Media -->
<section class="section section-light" id="books">
  <div class="container">
    <div class="books-grid">
      <div class="books-text reveal-left">
        <p class="section-label">Books &amp; Media</p>
        <h2 class="section-title">Educating America on Its Founding Principles</h2>
        <p>Judge Warren is not only a jurist &mdash; he is an educator, author, and media personality dedicated to preserving and promoting the First Principles of American liberty.</p>
        <p>Through his books, podcast, television appearances, and Patriot Week, he reaches thousands of Americans each year with a message of constitutional literacy and civic renewal.</p>
        <a href="<?php echo home_url('/media-appearances/'); ?>" class="btn btn-dark" style="margin-top:24px">Explore Media</a>
      </div>
      <div class="reveal-right">
        <div class="book-card" style="margin-bottom:24px">
          <h3>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:8px"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
            America's Survival Guide
          </h3>
          <p>A comprehensive guide to the First Principles that sustain American democracy &mdash; the values, ideas, and institutions that have made America exceptional.</p>
          <a href="https://www.amazon.com/Americas-Survival-Guide-Michael-Warren/dp/1934248312" target="_blank" rel="noopener">View on Amazon &rarr;</a>
        </div>
        <div class="book-card" style="margin-bottom:24px">
          <h3>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:8px"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
            The Revolutionary Words that Forged America
          </h3>
          <p>The definitive guide to the Declaration of Independence &mdash; a line-by-line analysis of America's charter, its drafting, historical circumstances, underlying philosophy, and legal force. (Republic Books, 2026)</p>
          <a href="https://www.amazon.com/Revolutionary-Words-that-Forged-America/dp/1645721205" target="_blank" rel="noopener">View on Amazon &rarr;</a>
        </div>
        <div class="book-card" style="margin-bottom:24px">
          <h3>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:8px"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            Patriot Week
          </h3>
          <p>Co-founded with his daughter Leah, Patriot Week is a national celebration renewing America's commitment to its First Principles and civic virtue.</p>
          <a href="https://www.PatriotWeek.org" target="_blank" rel="noopener">Visit Site &rarr;</a>
        </div>
        <div class="book-card">
          <h3>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:8px"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>
            Patriot Lessons
          </h3>
          <p>Judge Warren's podcast and TV show exploring the Constitution, American history, and the principles that preserve liberty for future generations.</p>
          <a href="<?php echo home_url('/media-appearances/'); ?>">Watch &amp; Listen &rarr;</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Get Involved CTA -->
<section class="section cta-section" id="contact">
  <div class="cta-overlay"></div>
  <div class="cursor-spotlight" id="ctaSpotlight" style="opacity:0;"></div>
  <div class="container">
    <div class="cta-grid">
      <div class="cta-text reveal-left">
        <p class="section-label" style="color:var(--accent-light);border-left-color:var(--accent-light)">Get Involved</p>
        <h2>We Win With Warren!</h2>
        <p>On November 3rd, 2026 &mdash; Vote Michael Warren for Michigan Supreme Court. Whether you want to learn more, donate, invite him to speak, or simply connect &mdash; reach out. Every voice matters in the fight to preserve our constitutional republic.</p>
        <a href="https://secure.anedot.com/michael-warren-for-supreme-court/donate" class="btn btn-donate" target="_blank" rel="noopener" style="margin-bottom:20px">Donate to the Campaign</a>
        <div class="social-links">
          <a href="https://www.facebook.com/WarrenforMI" target="_blank" rel="noopener" class="social-link" aria-label="Facebook">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
          </a>
          <a href="https://www.instagram.com/judgewarrenforMI" target="_blank" rel="noopener" class="social-link" aria-label="Instagram">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
          </a>
          <a href="https://www.youtube.com/@judgemichaelwarren" target="_blank" rel="noopener" class="social-link" aria-label="YouTube">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19.13C5.12 19.56 12 19.56 12 19.56s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.43z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"/></svg>
          </a>
          <a href="https://x.com/warrenformi" target="_blank" rel="noopener" class="social-link" aria-label="X/Twitter">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg>
          </a>
        </div>
      </div>
      <div class="contact-form reveal-right">
        <h3>Send a Message</h3>
        <form onsubmit="event.preventDefault();this.querySelector('.btn-submit').textContent='Message Sent!';this.reset();">
          <div class="form-group">
            <label for="name">Your Name</label>
            <input type="text" id="name" placeholder="John Smith" required>
          </div>
          <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" placeholder="john@example.com" required>
          </div>
          <div class="form-group">
            <label for="message">Message</label>
            <textarea id="message" placeholder="How can we help?" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-submit">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
            Send Message
          </button>
        </form>
      </div>
    </div>
  </div>
</section>

</main>

<!-- Footer -->
<footer class="footer" role="contentinfo">
  <div class="footer-bg"></div>
  <div class="footer-inner">
  <div class="container">
    <div class="footer-heading">Warren for Michigan Supreme Court</div>
    <div class="footer-grid">
      <div class="footer-brand">
        <img src="https://judgemichaelwarren.com/wp-content/uploads/2026/04/Logo-For-Judge-Warren.png" alt="Warren for Michigan Supreme Court" loading="lazy">
        <p>Judge Michael Warren &mdash; Candidate for Michigan Supreme Court. Defender of the Constitution with 400+ jury trials, constitutional law professor, author, Patriot Week co-founder. We Win With Warren!</p>
        <div class="footer-social">
          <a href="https://www.facebook.com/WarrenforMI" target="_blank" rel="noopener" aria-label="Facebook">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
          </a>
          <a href="https://www.instagram.com/judgewarrenforMI" target="_blank" rel="noopener" aria-label="Instagram">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
          </a>
          <a href="https://www.youtube.com/@judgemichaelwarren" target="_blank" rel="noopener" aria-label="YouTube">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19.13C5.12 19.56 12 19.56 12 19.56s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.43z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"/></svg>
          </a>
          <a href="https://x.com/warrenformi" target="_blank" rel="noopener" aria-label="X/Twitter">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg>
          </a>
        </div>
      </div>
      <div>
        <h4>Quick Links</h4>
        <ul>
          <li><a href="<?php echo home_url('/'); ?>">Home</a></li>
          <li><a href="<?php echo home_url('/about/'); ?>">About</a></li>
          <li><a href="<?php echo home_url('/media-appearances/'); ?>">Media</a></li>
        </ul>
      </div>
      <div>
        <h4>Resources</h4>
        <ul>
          <li><a href="https://www.amazon.com/Americas-Survival-Guide-Michael-Warren/dp/1934248312" target="_blank" rel="noopener">America's Survival Guide</a></li>
          <li><a href="https://www.PatriotWeek.org" target="_blank" rel="noopener">Patriot Week</a></li>
          <li><a href="<?php echo home_url('/media-appearances/'); ?>">Patriot Lessons</a></li>
        </ul>
      </div>
      <div>
        <h4>Contact</h4>
        <div class="footer-contact-item">
          <span class="footer-contact-icon">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
          </span>
          <a href="mailto:info@judgemichaelwarren.com">info@judgemichaelwarren.com</a>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <p class="footer-copyright">&copy; 2026 Judge Michael Warren. All rights reserved.</p>
      <p class="footer-credit">Built by <a href="https://kirkautomations.com" target="_blank" rel="noopener">Kirk Automations</a></p>
    </div>
  </div>
  </div>
</footer>

<!-- Back to Top -->
<button class="back-to-top" id="backToTop" aria-label="Back to top">
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg>
</button>

<!-- Cookie Consent -->
<div class="cookie-banner" id="cookieBanner" role="dialog" aria-label="Cookie consent">
  <p>We use cookies to enhance your browsing experience and analyze site traffic. By continuing, you agree to our use of cookies.</p>
  <div class="cookie-btns">
    <button class="cookie-accept" id="cookieAccept">Accept</button>
    <button class="cookie-decline" id="cookieDecline">Decline</button>
  </div>
</div>

<script>
(function(){
  'use strict';

  /* --- Loading Screen --- */
  var loader=document.getElementById('loader');
  if(loader){
    if(sessionStorage.getItem('warren-loaded')){loader.classList.add('hidden')}
    else{setTimeout(function(){loader.classList.add('hidden');sessionStorage.setItem('warren-loaded','1')},1800)}
  }



  /* --- Sticky Nav + Scroll Progress + Back to Top --- */
  var nav=document.getElementById('navbar');
  window.addEventListener('scroll',function(){
    var scrollY=window.scrollY;
    if(nav)nav.classList.toggle('scrolled',scrollY>80);
    var progress=document.getElementById('scrollProgress');
    if(progress){var docH=document.documentElement.scrollHeight-window.innerHeight;progress.style.width=docH>0?(scrollY/docH*100)+'%':'0%'}
    var btt=document.getElementById('backToTop');
    if(btt)btt.classList.toggle('show',scrollY>500);
  },{passive:true});

  /* Back to top click */
  var btt=document.getElementById('backToTop');
  if(btt)btt.addEventListener('click',function(){window.scrollTo({top:0,behavior:'smooth'})});

  /* --- Mobile Menu --- */
  var hamburger=document.getElementById('hamburger');
  var mobileMenu=document.getElementById('mobileMenu');
  var mobileOverlay=document.getElementById('mobileOverlay');
  if(hamburger&&mobileMenu&&mobileOverlay){
    var toggleMenu=function(){
      var open=mobileMenu.classList.toggle('open');
      hamburger.classList.toggle('active');
      mobileOverlay.classList.toggle('show');
      hamburger.setAttribute('aria-expanded',open);
      document.body.style.overflow=open?'hidden':'';
    };
    hamburger.addEventListener('click',toggleMenu);
    mobileOverlay.addEventListener('click',toggleMenu);
    mobileMenu.querySelectorAll('a').forEach(function(a){a.addEventListener('click',function(){if(mobileMenu.classList.contains('open'))toggleMenu()})});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&mobileMenu.classList.contains('open'))toggleMenu()});
  }

  /* --- Cookie Consent --- */
  var cookieBanner=document.getElementById('cookieBanner');
  if(cookieBanner&&!localStorage.getItem('warren-cookies')){
    setTimeout(function(){cookieBanner.classList.add('show')},2500);
  }
  var ca=document.getElementById('cookieAccept');if(ca)ca.addEventListener('click',function(){localStorage.setItem('warren-cookies','accepted');cookieBanner.classList.remove('show')});
  var cd=document.getElementById('cookieDecline');if(cd)cd.addEventListener('click',function(){localStorage.setItem('warren-cookies','declined');cookieBanner.classList.remove('show')});

  /* --- Scroll Reveal (IntersectionObserver) --- */
  var reveals=document.querySelectorAll('.reveal,.reveal-left,.reveal-right');
  if('IntersectionObserver' in window){
    var observer=new IntersectionObserver(function(entries){
      entries.forEach(function(entry){if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target)}});
    },{threshold:0.1,rootMargin:'0px 0px -50px 0px'});
    reveals.forEach(function(el){observer.observe(el)});
  }else{reveals.forEach(function(el){el.classList.add('visible')})}

  /* --- Counter Animation --- */
  var counters=document.querySelectorAll('[data-target]');
  if(counters.length&&'IntersectionObserver' in window){
    var counterObserver=new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting){
          var el=entry.target;var target=parseInt(el.dataset.target);
          var prefix=el.dataset.prefix||'';var suffix=el.dataset.suffix||'';
          var current=0;var step=Math.max(1,Math.floor(target/60));
          var timer=setInterval(function(){
            current+=step;if(current>=target){current=target;clearInterval(timer)}
            el.textContent=prefix+current.toLocaleString()+suffix;
          },30);
          counterObserver.unobserve(el);
        }
      });
    },{threshold:0.3});
    counters.forEach(function(c){counterObserver.observe(c)});
  }

  /* --- Parallax Tilt on Cards --- */
  document.querySelectorAll('[data-tilt]').forEach(function(card){
    card.addEventListener('mousemove',function(e){
      var rect=card.getBoundingClientRect();
      var x=(e.clientX-rect.left)/rect.width-0.5;
      var y=(e.clientY-rect.top)/rect.height-0.5;
      card.style.transform='perspective(1000px) rotateY('+x*8+'deg) rotateX('+-y*8+'deg) translateY(-8px)';
    });
    card.addEventListener('mouseleave',function(){card.style.transform=''});
  });

  /* --- Magnetic Buttons --- */
  document.querySelectorAll('.btn').forEach(function(btn){
    btn.addEventListener('mousemove',function(e){
      var rect=btn.getBoundingClientRect();
      var x=e.clientX-rect.left-rect.width/2;
      var y=e.clientY-rect.top-rect.height/2;
      btn.style.transform='translate('+x*0.15+'px,'+y*0.15+'px)';
    });
    btn.addEventListener('mouseleave',function(){btn.style.transform=''});
  });

  /* --- Cursor Spotlight on Dark Sections --- */
  function setupSpotlight(sectionId,spotlightId){
    var section=document.getElementById(sectionId);
    var spot=document.getElementById(spotlightId);
    if(!section||!spot)return;
    section.addEventListener('mousemove',function(e){
      var rect=section.getBoundingClientRect();
      spot.style.left=(e.clientX-rect.left)+'px';
      spot.style.top=(e.clientY-rect.top)+'px';
      spot.style.opacity='1';
    });
    section.addEventListener('mouseleave',function(){spot.style.opacity='0'});
  }
  setupSpotlight('heroSection','heroSpotlight');
  setupSpotlight('stats','statsSpotlight');
  setupSpotlight('contact','ctaSpotlight');

  /* --- Hero Mouse Particles --- */
  var heroParticles=document.getElementById('heroParticles');
  var heroSection=document.getElementById('heroSection');
  if(heroParticles&&heroSection){
    var particleCount=0;
    heroSection.addEventListener('mousemove',function(e){
      if(particleCount>30||window.innerWidth<768)return;
      var rect=heroSection.getBoundingClientRect();
      var particle=document.createElement('div');
      particleCount++;
      var size=Math.random()*5+2;
      particle.style.cssText='position:absolute;left:'+(e.clientX-rect.left)+'px;top:'+(e.clientY-rect.top)+'px;width:'+size+'px;height:'+size+'px;border-radius:50%;background:rgba(var(--particle-color),'+(Math.random()*0.5+0.3)+');pointer-events:none;transition:all 1s ease;z-index:5';
      heroParticles.appendChild(particle);
      requestAnimationFrame(function(){
        particle.style.transform='translate('+(Math.random()-0.5)*80+'px,'+(Math.random()-0.5)*80+'px)';
        particle.style.opacity='0';
      });
      setTimeout(function(){particle.remove();particleCount--},1000);
    });
  }

  /* --- Parallax Background Shift --- */
  var heroBg=document.getElementById('heroBg');
  window.addEventListener('scroll',function(){
    var scrollY=window.scrollY;
    if(heroBg)heroBg.style.transform='translateY('+scrollY*0.3+'px)';
  },{passive:true});

  /* --- Typing Effect --- */
  var typingEl=document.getElementById('typingText');
  if(typingEl){
    var phrases=['We Win With Warren!','Defender of the Constitution','More trial experience than the entire current Supreme Court combined','Interprets the law as written \u2014 does not legislate from the bench','Judge of the Decade \u2014 IAOTP','Vote Warren for Michigan Supreme Court \u2014 November 2026'];
    var phraseIndex=0,charIndex=0,isDeleting=false;
    function typeEffect(){
      var current=phrases[phraseIndex];
      if(!isDeleting){
        typingEl.textContent=current.substring(0,charIndex+1);
        charIndex++;
        if(charIndex===current.length){isDeleting=true;setTimeout(typeEffect,2000);return}
        setTimeout(typeEffect,60+Math.random()*40);
      }else{
        typingEl.textContent=current.substring(0,charIndex-1);
        charIndex--;
        if(charIndex===0){isDeleting=false;phraseIndex=(phraseIndex+1)%phrases.length;setTimeout(typeEffect,500);return}
        setTimeout(typeEffect,30);
      }
    }
    setTimeout(typeEffect,2200);
  }

  /* --- Smooth Anchor Scroll --- */
  document.querySelectorAll('a[href^="#"]').forEach(function(a){
    a.addEventListener('click',function(e){
      var target=document.querySelector(a.getAttribute('href'));
      if(target){e.preventDefault();target.scrollIntoView({behavior:'smooth'})}
    });
  });

})();
</script>

<!-- Paid For Disclaimer &mdash; Legal Requirement -->
<div class="paid-for-disclaimer">
  Paid for by Michael Warren for Supreme Court &bull; PO Box 1182 &bull; Brighton, MI 48116
</div>

<?php wp_footer(); ?>
</body>
</html>